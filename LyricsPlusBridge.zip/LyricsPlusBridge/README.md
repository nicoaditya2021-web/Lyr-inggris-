# Lyrics Plus Bridge — Music Player + Synced Lyrics for Minecraft Bedrock (LeviLauncher, Android)

Panel now-playing ala Lyrics Plus (cover, judul/artis/album, progress, Play/Pause/Next/Prev,
lirik tersinkron dengan highlight baris aktif) yang tampil **di atas Minecraft** saat dijalankan lewat LeviLauncher.

## STATUS JUJUR
| Bagian | Status |
|---|---|
| Baca MediaSession (Spotify, YT Music, YouTube, dll.) | Ditulis, **belum dikompilasi/diuji di perangkat** |
| Kontrol Play/Pause/Next/Prev/Seek | Ditulis, belum diuji |
| Lirik (LRCLIB) + sinkronisasi + animasi | Ditulis, belum diuji |
| Panel overlay + semua pengaturan | Ditulis, belum diuji |
| Mod native `.so` di dalam proses game | **Belum dibuat** (lihat bawah) |

Kode ditulis tanpa Android SDK, jadi **build pertama bisa menampilkan error kompilasi kecil**. Kirim lognya, nanti diperbaiki.

### Kenapa bukan mod `.so`?
Pack Bedrock tidak bisa membaca MediaSession. LeviLauncher memang memuat modul native, tapi
API menggambar UI-nya (header Preloader) belum bisa saya lihat, dan hook render bergantung versi Minecraft.
Menulis C++ tebakan hanya akan menghasilkan kode yang tidak jalan. Maka panel digambar oleh APK sebagai overlay;
hasilnya tampil di atas game, dengan kontrol sentuh nyata. Server lokal `127.0.0.1:38417` (lihat `docs/PROTOCOL.md`)
sudah disiapkan agar mod native bisa disambungkan nanti.

Font: panel memakai font sistem Android (sans-serif). Font Minecraft milik Mojang tidak disertakan.

## Build (tanpa PC)
1. Buat repo GitHub, upload seluruh isi folder ini.
2. Tab **Actions** → *Build APK* → tunggu selesai → unduh artifact `LyricsPlusBridge-apk` (berisi `app-debug.apk`).
Atau di PC: Android Studio → Open → Run. (JDK 17, Gradle 8.7)

## Instalasi
1. Install APK, buka **Lyrics Plus Bridge**.
2. Tombol 1: aktifkan **Notification Access** untuk Lyrics Plus Bridge (wajib, ini cara Android memberi akses MediaSession).
3. Tombol 2: izinkan **Display over other apps**.
4. Tombol 3: **Start panel**. Izinkan notifikasi jika diminta.
5. Putar lagu di Spotify / YouTube Music.
6. Buka Minecraft lewat **LeviLauncher** seperti biasa; panel muncul di atas game.
   Seret panel untuk memindahkannya; ketuk tombol/progress bar untuk mengontrol.

Tips: matikan penghemat baterai untuk Lyrics Plus Bridge, Spotify dan LeviLauncher agar tidak dihentikan Android.

## Lirik melayang + pill karaoke (v1.1)
Terinspirasi video referensi: kata-kata lirik muncul satu per satu, melengkung di layar, dan pill di atas
menampilkan baris aktif dengan kata yang disorot, cover kecil, dan equalizer.
Pengaturan: Floating lyrics, Top karaoke pill, ALL CAPS, warna huruf = warna album, Lyric Size, Font, Shadow.

Batasan jujur:
- Lirik digambar di **layar (2D)**, tidak menempel di dunia 3D Minecraft dan tidak mengikuti kamera seperti di video.
  Itu butuh mod native yang masuk ke renderer game.
- Waktu per kata **diperkirakan** (LRCLIB hanya punya waktu per baris), jadi sorotan kata bisa sedikit meleset.
- Overlay layar penuh (tembus sentuh) menambah sedikit beban; matikan "Floating lyrics" bila game terasa berat.
- Pill di tengah atas bisa menutupi tombol Minecraft; matikan "Top karaoke pill" bila mengganggu.

## Tampilan aplikasi (v1.3, gaya kaca)
Menu aplikasi memakai gaya "liquid glass": latar bergerak berwarna mengikuti cover lagu, kartu kaca,
nav bar mengambang dengan lensa yang meregang saat digeser, mini player kaca (prev/play/next sungguhan),
dan animasi halaman/ toggle/ tombol. Efek kaca ini **ditiru** (transparan + gradien + border),
bukan blur asli dari konten di belakangnya.

## Pengaturan
Enable Music UI, Enable Lyrics, UI Scale, Panel Position (+ seret bebas), Animation Speed,
Background Opacity, Show Album Cover, Show Progress Bar.

## Batasan
- Lirik butuh internet dan hanya muncul bila ada di LRCLIB.
- Aplikasi yang tidak mengirim cover/durasi ke MediaSession akan tampil tanpa cover/progress.
- Overlay menutupi sebagian layar: letakkan di area yang aman lewat Panel Position.
