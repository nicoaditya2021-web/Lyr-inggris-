package com.lyricsplus.bridge

import android.graphics.Bitmap
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Loopback-only HTTP bridge (127.0.0.1:38417) so other local programs
 * (e.g. a native LeviLauncher mod) can read now-playing data and send controls.
 *
 *   GET /status            -> {"status":"ok","mod":"LyricsPlusBridge"}
 *   GET /state             -> JSON with title, artist, album, durationMs, positionMs, playing, lyrics...
 *   GET /cover.jpg         -> album cover (JPEG), 404 if none
 *   GET|POST /cmd/toggle|play|pause|next|prev
 *   GET|POST /seek?ms=12345
 */
class LocalServer {
    companion object { const val PORT = 38417 }

    @Volatile private var running = false
    private var ss: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        thread(isDaemon = true, name = "lp-server") {
            try {
                ss = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
                while (running) {
                    val s = ss!!.accept()
                    thread(isDaemon = true) { handle(s) }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun stop() {
        running = false
        try { ss?.close() } catch (_: Exception) {}
    }

    private fun handle(s: Socket) {
        s.use {
            try {
                s.soTimeout = 3000
                val r = s.getInputStream().bufferedReader()
                val first = r.readLine() ?: return
                var line = r.readLine()
                while (!line.isNullOrEmpty()) line = r.readLine()
                val target = first.split(" ").getOrElse(1) { "/" }
                val path = target.substringBefore('?')
                val query = target.substringAfter('?', "")
                val out = s.getOutputStream()
                when {
                    path == "/status" -> json(out, "{\"status\":\"ok\",\"mod\":\"LyricsPlusBridge\"}")
                    path == "/state" -> json(out, state().toString())
                    path == "/cover.jpg" -> cover(out)
                    path.startsWith("/cmd/") -> {
                        when (path.removePrefix("/cmd/")) {
                            "toggle" -> MediaState.toggle()
                            "play" -> MediaState.play()
                            "pause" -> MediaState.pause()
                            "next" -> MediaState.next()
                            "prev" -> MediaState.prev()
                            else -> { send(out, 404, "text/plain", "unknown".toByteArray()); return }
                        }
                        json(out, "{\"ok\":true}")
                    }
                    path == "/seek" -> {
                        val ms = query.split("&").firstOrNull { it.startsWith("ms=") }
                            ?.removePrefix("ms=")?.toLongOrNull()
                        if (ms != null) MediaState.seekTo(ms)
                        json(out, "{\"ok\":${ms != null}}")
                    }
                    else -> send(out, 404, "text/plain", "not found".toByteArray())
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun state(): JSONObject {
        val t = MediaState.track
        val o = JSONObject()
        o.put("hasTrack", t != null)
        o.put("title", t?.title ?: "")
        o.put("artist", t?.artist ?: "")
        o.put("album", t?.album ?: "")
        o.put("durationMs", t?.durationMs ?: 0L)
        o.put("positionMs", MediaState.position())
        o.put("playing", MediaState.playing)
        o.put("package", t?.pkg ?: "")
        o.put("trackId", MediaState.trackId)
        o.put("hasCover", t?.cover != null)
        val l = LyricsRepo.lines
        val i = LyricsRepo.indexAt(MediaState.position())
        o.put("lyricsStatus", LyricsRepo.status)
        o.put("lyricIndex", i)
        o.put("lyricPrev", l.getOrNull(i - 1)?.text ?: "")
        o.put("lyricCurrent", l.getOrNull(i)?.text ?: "")
        o.put("lyricNext", l.getOrNull(i + 1)?.text ?: "")
        return o
    }

    private fun cover(out: OutputStream) {
        val b: Bitmap? = MediaState.track?.cover
        if (b == null) { send(out, 404, "text/plain", "no cover".toByteArray()); return }
        val bo = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 85, bo)
        send(out, 200, "image/jpeg", bo.toByteArray())
    }

    private fun json(out: OutputStream, body: String) = send(out, 200, "application/json", body.toByteArray())

    private fun send(out: OutputStream, code: Int, type: String, body: ByteArray) {
        val head = "HTTP/1.1 $code ${if (code == 200) "OK" else "Not Found"}\r\n" +
                "Content-Type: $type\r\nContent-Length: ${body.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray())
        out.write(body)
        out.flush()
    }
}
