package com.lyricsplus.bridge

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var st: Settings
    private lateinit var root: FrameLayout
    private lateinit var pagesHost: FrameLayout
    private lateinit var nav: NavBar
    private lateinit var mini: GlassLayout
    private val pages = ArrayList<ScrollView>()
    private var cur = 0
    private var topInset = 0
    private var botInset = 0
    private var miniShown = false

    // live-updated views
    private lateinit var heroTitle: TextView
    private lateinit var heroArtist: TextView
    private lateinit var heroChip: TextView
    private lateinit var heroCover: ImageView
    private lateinit var heroPlay: IconButton
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniCover: ImageView
    private lateinit var miniPlay: IconButton
    private lateinit var stNotif: TextView
    private lateinit var stOverlay: TextView
    private lateinit var btnService: TextView
    private lateinit var stWs: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 400)
        }
    }

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    // ================================================================= lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = Settings(this)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        root = FrameLayout(this)
        root.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        root.addView(GlassBg(this), FrameLayout.LayoutParams(-1, -1))

        pagesHost = FrameLayout(this)
        root.addView(pagesHost, FrameLayout.LayoutParams(-1, -1))

        pages.add(buildHome())
        pages.add(buildLyrics())
        pages.add(build3d())
        pages.add(buildSettings())
        for ((i, p) in pages.withIndex()) {
            pagesHost.addView(p, FrameLayout.LayoutParams(-1, -1))
            p.visibility = if (i == 0) View.VISIBLE else View.GONE
        }

        buildMini()
        nav = NavBar(this, listOf("Home", "Lyrics", "3D", "Settings")) { select(it) }
        root.addView(nav, FrameLayout.LayoutParams(-1, dp(66)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(18); rightMargin = dp(18)
        })

        root.setOnApplyWindowInsetsListener { _, ins ->
            @Suppress("DEPRECATION")
            run { topInset = ins.systemWindowInsetTop; botInset = ins.systemWindowInsetBottom }
            applyInsets()
            ins
        }
        applyInsets()
        setContentView(root)
        stagger(pages[0])
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }

    private fun applyInsets() {
        val navBottom = dp(14) + botInset
        (nav.layoutParams as FrameLayout.LayoutParams).bottomMargin = navBottom
        nav.requestLayout()
        val miniLp = mini.layoutParams as FrameLayout.LayoutParams
        miniLp.bottomMargin = navBottom + dp(66) + dp(10)
        mini.requestLayout()
        for (p in pages) {
            p.setPadding(0, topInset, 0, 0)
            (p.getChildAt(0) as View).setPadding(dp(18), dp(22), dp(18), navBottom + dp(66) + dp(10) + dp(72) + dp(24))
        }
    }

    private fun select(i: Int) {
        if (i == cur) return
        val old = pages[cur]
        val nw = pages[i]
        cur = i
        for (p in pages) p.animate().cancel()
        for (p in pages) if (p !== old && p !== nw) p.visibility = View.GONE
        nw.visibility = View.VISIBLE
        nw.alpha = 0f
        nw.animate().alpha(1f).setDuration(300).setInterpolator(DecelerateInterpolator(2f)).start()
        old.animate().alpha(0f).setDuration(160).withEndAction { if (old !== pages[cur]) old.visibility = View.GONE }.start()
        stagger(nw)
    }

    private fun stagger(page: ScrollView) {
        page.scrollTo(0, 0)
        val col = page.getChildAt(0) as ViewGroup
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dpf(20f)
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 45L).setDuration(420)
                .setInterpolator(DecelerateInterpolator(2.2f))
                .withEndAction { v.animate().setStartDelay(0) }
                .start()
        }
    }

    // ================================================================= small builders
    private fun tv(text: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = Typeface.create(if (bold) "sans-serif" else "sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    private fun lp(w: Int, h: Int, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { bottomMargin = dp(bottom) }

    private fun newPage(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        sv.addView(col, ViewGroup.LayoutParams(-1, -2))
        return Pair(sv, col)
    }

    private fun header(col: LinearLayout, title: String, sub: String? = null) {
        col.addView(tv(title, 30f, Color.WHITE, true), lp(-2, -2, 2))
        if (sub != null) col.addView(tv(sub, 13f, 0x99FFFFFF.toInt()), lp(-2, -2, 16))
        else (col.getChildAt(col.childCount - 1).layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(16)
    }

    private fun card(col: LinearLayout, title: String? = null, radius: Float = 24f): LinearLayout {
        val g = GlassLayout(this, radius, 26)
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        inner.setPadding(dp(18), dp(16), dp(18), dp(16))
        g.addView(inner, FrameLayout.LayoutParams(-1, -2))
        col.addView(g, lp(-1, -2, 14))
        if (title != null) inner.addView(tv(title.uppercase(), 11.5f, 0xFF67E8F9.toInt(), true), lp(-2, -2, 6))
        return inner
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = tv(text, 13f, Color.WHITE, true)
        t.setPadding(dp(16), dp(9), dp(16), dp(9))
        val g = GradientDrawable()
        g.cornerRadius = dpf(22f)
        g.setColor(Color.argb(44, 255, 255, 255))
        g.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        t.background = g
        t.setOnClickListener { onClick() }
        Ui.press(t)
        return t
    }

    private fun setChip(t: TextView, selected: Boolean) {
        val g = GradientDrawable()
        g.cornerRadius = dpf(22f)
        if (selected) {
            g.setColor(Color.argb(238, 255, 255, 255)); t.setTextColor(Color.rgb(16, 16, 20))
        } else {
            g.setColor(Color.argb(34, 255, 255, 255)); g.setStroke(dp(1), Color.argb(70, 255, 255, 255)); t.setTextColor(Color.WHITE)
        }
        t.background = g
    }

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    private fun coverView(size: Int, radius: Float): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.outlineProvider = roundOutline(dpf(radius))
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        iv.setImageDrawable(placeholder())
        return iv
    }

    private fun placeholder(): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF22D3EE.toInt(), 0xFF7C3AED.toInt()))
        return g
    }

    private fun row(card: LinearLayout, label: String, sub: String?, control: View) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(label, 15f))
        if (sub != null) col.addView(tv(sub, 12f, 0x88FFFFFF.toInt()))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(control)
        r.setPadding(0, dp(8), 0, dp(8))
        card.addView(r, lp(-1, -2))
    }

    private fun toggleRow(card: LinearLayout, label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val t = GlassToggle(this)
        t.setState(get(), false)
        t.onChange = { set(it); reload() }
        row(card, label, null, t)
    }

    private fun sliderRow(card: LinearLayout, label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(tv(label, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        val value = tv("${get()}", 14f, 0xFF67E8F9.toInt(), true)
        head.addView(value)
        head.setPadding(0, dp(10), 0, 0)
        card.addView(head, lp(-1, -2))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = get() - min
        sb.progressTintList = ColorStateList.valueOf(0xFF22D3EE.toInt())
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = "${p + min}" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { set((s?.progress ?: 0) + min); reload() }
        })
        card.addView(sb, lp(-1, -2))
    }

    private fun chipsRow(card: LinearLayout, label: String, names: List<String>, get: () -> Int, set: (Int) -> Unit) {
        card.addView(tv(label, 15f), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10); bottomMargin = dp(8) })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        for ((i, n) in names.withIndex()) {
            val c = tv(n, 13f, Color.WHITE, false)
            c.setPadding(dp(16), dp(9), dp(16), dp(9))
            setChip(c, i == get())
            Ui.press(c)
            c.setOnClickListener {
                set(i); for ((j, o) in chips.withIndex()) setChip(o, j == i); reload()
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        hs.addView(row)
        card.addView(hs, lp(-1, -2))
    }

    // ================================================================= pages
    private fun buildHome(): ScrollView {
        val (sv, col) = newPage()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when { h < 11 -> "Good morning"; h < 15 -> "Good afternoon"; h < 18 -> "Good evening"; else -> "Good night" }
        header(col, greet, "Lyrics Plus Bridge")

        // hero now-playing
        val hero = card(col, null, 30f)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        heroCover = coverView(96, 20f)
        top.addView(heroCover)
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        heroTitle = tv("No song yet", 19f, Color.WHITE, true)
        heroTitle.maxLines = 2
        heroArtist = tv("Play a song on Spotify or YouTube Music", 13f, 0xAAFFFFFF.toInt())
        heroArtist.maxLines = 2
        heroChip = tv("—", 11f, Color.WHITE, true)
        heroChip.setPadding(dp(10), dp(3), dp(10), dp(3))
        val cg = GradientDrawable(); cg.cornerRadius = dpf(12f); cg.setColor(Color.argb(50, 255, 255, 255))
        heroChip.background = cg
        texts.addView(heroTitle)
        texts.addView(heroArtist, lp(-2, -2, 8))
        texts.addView(heroChip)
        top.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        hero.addView(top, lp(-1, -2, 6))
        hero.addView(GlassProgress(this), lp(-1, -2, 0))

        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        val prev = IconButton(this, IconButton.PREV).also { it.setSizeDp(52); it.setOnClickListener { MediaState.prev() } }
        heroPlay = IconButton(this, IconButton.PLAY).also { it.setSizeDp(68); it.setOnClickListener { MediaState.toggle() } }
        val next = IconButton(this, IconButton.NEXT).also { it.setSizeDp(52); it.setOnClickListener { MediaState.next() } }
        ctl.addView(prev); ctl.addView(heroPlay, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(18); rightMargin = dp(18) }); ctl.addView(next)
        hero.addView(ctl, lp(-1, -2))

        // setup
        val setup = card(col, "Initial setup")
        stNotif = statusRow(setup, "Notification Access", "Set up") {
            startActivity(Intent(AndroidSettings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        stOverlay = statusRow(setup, "Display over other apps", "Set up") {
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnService = pill("Start panel") {
            if (OverlayService.running) {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            } else {
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            }
            ui.postDelayed({ refreshStatus() }, 400)
        }
        row(setup, "In-game panel", "Overlay + local server", btnService)

        col.addView(tv("Tip: drag the panel in-game to move it.", 12f, 0x77FFFFFF.toInt()), lp(-2, -2, 0))
        return sv
    }

    private fun statusRow(card: LinearLayout, label: String, action: String, onClick: () -> Unit): TextView {
        val s = tv("●", 14f, 0xFFF87171.toInt(), true)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.addView(s, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) })
        l.addView(tv(label, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        l.addView(pill(action, onClick))
        l.setPadding(0, dp(6), 0, dp(6))
        card.addView(l, lp(-1, -2))
        return s
    }

    private fun buildLyrics(): ScrollView {
        val (sv, col) = newPage()
        header(col, "Lyrics", "Floating lyrics on screen + karaoke pill")
        val c = card(col, "Basics")
        toggleRow(c, "Enable Lyrics", { st.lyrics }) { st.lyrics = it }
        toggleRow(c, "Floating lyrics (curved)", { st.floatLyrics }) { st.floatLyrics = it }
        toggleRow(c, "Top karaoke pill", { st.topPill }) { st.topPill = it }
        val s = card(col, "Style")
        toggleRow(s, "ALL CAPS", { st.floatCaps }) { st.floatCaps = it }
        toggleRow(s, "Text color = album color", { st.floatAccent }) { st.floatAccent = it }
        sliderRow(s, "Lyric Size (%)", 50, 200, { st.floatSize }) { st.floatSize = it }
        chipsRow(s, "Font", Settings.FONT_NAMES, { st.floatFont }) { st.floatFont = it }
        chipsRow(s, "Shadow", Settings.SHADOW_NAMES, { st.floatShadow }) { st.floatShadow = it }
        return sv
    }

    private fun build3d(): ScrollView {
        val (sv, col) = newPage()
        header(col, "3D Lyrics", "Lyrics Plus 3D add-on in the Minecraft world")
        val c = card(col, "Connection")
        stWs = tv("✘ Minecraft not connected", 14f, 0xFFF87171.toInt(), true)
        c.addView(stWs, lp(-2, -2, 8))
        c.addView(tv("In Minecraft (cheats ON), type once per session:", 12.5f, 0xAAFFFFFF.toInt()), lp(-2, -2, 4))
        c.addView(tv("/wsserver ws://127.0.0.1:8765", 14f, 0xFF67E8F9.toInt(), true), lp(-2, -2, 10))
        c.addView(pill("Copy command") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("cmd", "/wsserver ws://127.0.0.1:8765"))
            Toast.makeText(this, "Command copied", Toast.LENGTH_SHORT).show()
        })
        val s = card(col, "3D settings")
        toggleRow(s, "Send lyrics to add-on", { st.w3dOn }) { st.w3dOn = it }
        sliderRow(s, "3D Text Size (%)", 50, 250, { st.w3dSize }) { st.w3dSize = it }
        sliderRow(s, "3D Distance (blocks)", 3, 14, { st.w3dDist }) { st.w3dDist = it }
        toggleRow(s, "Text follows camera", { st.w3dFollow }) { st.w3dFollow = it }
        return sv
    }

    private fun buildSettings(): ScrollView {
        val (sv, col) = newPage()
        header(col, "Settings", "In-game music panel")
        val c = card(col, "Panel")
        toggleRow(c, "Enable Music UI", { st.musicUi }) { st.musicUi = it }
        toggleRow(c, "Show Album Cover", { st.showCover }) { st.showCover = it }
        toggleRow(c, "Show Progress Bar", { st.showProgress }) { st.showProgress = it }
        val s = card(col, "Appearance")
        sliderRow(s, "UI Scale (%)", 50, 200, { st.scale }) { st.scale = it }
        sliderRow(s, "Animation Speed (%)", 25, 200, { st.animSpeed }) { st.animSpeed = it }
        sliderRow(s, "Background Opacity (%)", 0, 100, { st.bgOpacity }) { st.bgOpacity = it }
        chipsRow(s, "Panel Position", Settings.POSITION_NAMES, { st.position }) { st.position = it }
        return sv
    }

    // ================================================================= mini player
    private fun buildMini() {
        mini = GlassLayout(this, 32f, 30)
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(10), dp(8), dp(12), dp(8))
        miniCover = coverView(48, 14f)
        r.addView(miniCover)
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        miniTitle = tv("", 14f, Color.WHITE, true); miniTitle.maxLines = 1; miniTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        miniArtist = tv("", 12f, 0xAAFFFFFF.toInt()); miniArtist.maxLines = 1; miniArtist.ellipsize = android.text.TextUtils.TruncateAt.END
        t.addView(miniTitle); t.addView(miniArtist)
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12); rightMargin = dp(8) })
        val prev = IconButton(this, IconButton.PREV).also { it.setSizeDp(38); it.setOnClickListener { MediaState.prev() } }
        miniPlay = IconButton(this, IconButton.PLAY).also { it.setSizeDp(44); it.setOnClickListener { MediaState.toggle() } }
        val next = IconButton(this, IconButton.NEXT).also { it.setSizeDp(38); it.setOnClickListener { MediaState.next() } }
        r.addView(prev); r.addView(miniPlay, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(4); rightMargin = dp(4) }); r.addView(next)
        mini.addView(r, FrameLayout.LayoutParams(-1, -1))
        mini.setOnClickListener { nav.setSelected(0); select(0) }
        mini.alpha = 0f
        mini.visibility = View.GONE
        root.addView(mini, FrameLayout.LayoutParams(-1, dp(72)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(12); rightMargin = dp(12)
        })
    }

    private fun showMini(show: Boolean) {
        if (show == miniShown) return
        miniShown = show
        mini.animate().cancel()
        if (show) {
            mini.visibility = View.VISIBLE
            mini.translationY = dpf(40f)
            mini.animate().alpha(1f).translationY(0f).setDuration(420)
                .setInterpolator(android.view.animation.OvershootInterpolator(1.1f)).start()
        } else {
            mini.animate().alpha(0f).translationY(dpf(40f)).setDuration(260)
                .withEndAction { if (!miniShown) mini.visibility = View.GONE }.start()
        }
    }

    private fun setCover(iv: ImageView, bmp: Bitmap?) {
        if (iv.tag === bmp && iv.tag != null) return
        if (bmp == null && iv.tag == null) return
        iv.tag = bmp
        iv.animate().cancel()
        iv.animate().alpha(0f).setDuration(120).withEndAction {
            if (bmp == null) iv.setImageDrawable(placeholder()) else iv.setImageBitmap(bmp)
            iv.animate().alpha(1f).setDuration(260).start()
        }.start()
    }

    private fun setText(t: TextView, s: String) { if (t.text.toString() != s) t.text = s }

    private fun refreshStatus() {
        val n = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        stNotif.setTextColor(if (n) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())
        val o = AndroidSettings.canDrawOverlays(this)
        stOverlay.setTextColor(if (o) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())
        setText(btnService, if (OverlayService.running) "Stop panel" else "Start panel")
        stWs.text = if (OverlayService.wsConnected) "✔ Minecraft connected (3D lyrics active)" else "✘ Minecraft not connected"
        stWs.setTextColor(if (OverlayService.wsConnected) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())

        val t = MediaState.track
        val playing = MediaState.playing
        setText(heroTitle, t?.title ?: "No song yet")
        setText(heroArtist, t?.let { if (it.album.isNotBlank()) "${it.artist} • ${it.album}" else it.artist }
            ?: "Play a song on Spotify or YouTube Music")
        setText(heroChip, if (t == null) "Waiting for music" else if (playing) "Playing" else "Paused")
        heroPlay.setPlaying(playing)
        setCover(heroCover, t?.cover)

        showMini(t != null)
        if (t != null) {
            setText(miniTitle, t.title)
            setText(miniArtist, t.artist)
            miniPlay.setPlaying(playing)
            setCover(miniCover, t.cover)
        }
    }

    private fun reload() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RELOAD))
        }
    }
}
