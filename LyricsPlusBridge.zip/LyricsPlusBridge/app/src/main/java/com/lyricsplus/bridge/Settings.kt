package com.lyricsplus.bridge

import android.content.Context

/** All user settings (persisted in SharedPreferences). */
class Settings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("lp_settings", Context.MODE_PRIVATE)

    companion object {
        /** 0 TL, 1 TC, 2 TR, 3 BL, 4 BC, 5 BR, 6 custom (dragged) */
        val POSITION_NAMES = listOf(
            "Top Left", "Top Center", "Top Right",
            "Bottom Left", "Bottom Center", "Bottom Right", "Custom (dragged)"
        )
        val FONT_NAMES = listOf("Bold", "Black (heavy)", "Condensed", "Serif", "Casual", "Mono")
        val SHADOW_NAMES = listOf("Off", "Soft", "Strong")
    }

    var musicUi: Boolean
        get() = sp.getBoolean("musicUi", true)
        set(v) { sp.edit().putBoolean("musicUi", v).apply() }

    var lyrics: Boolean
        get() = sp.getBoolean("lyrics", true)
        set(v) { sp.edit().putBoolean("lyrics", v).apply() }

    var showCover: Boolean
        get() = sp.getBoolean("showCover", true)
        set(v) { sp.edit().putBoolean("showCover", v).apply() }

    var showProgress: Boolean
        get() = sp.getBoolean("showProgress", true)
        set(v) { sp.edit().putBoolean("showProgress", v).apply() }

    /** percent, 50..200 */
    var scale: Int
        get() = sp.getInt("scale", 100)
        set(v) { sp.edit().putInt("scale", v).apply() }

    /** percent, 25..200 */
    var animSpeed: Int
        get() = sp.getInt("animSpeed", 100)
        set(v) { sp.edit().putInt("animSpeed", v).apply() }

    /** percent, 0..100 */
    var bgOpacity: Int
        get() = sp.getInt("bgOpacity", 78)
        set(v) { sp.edit().putInt("bgOpacity", v).apply() }

    var position: Int
        get() = sp.getInt("position", 0)
        set(v) { sp.edit().putInt("position", v).apply() }

    var customX: Int
        get() = sp.getInt("customX", 24)
        set(v) { sp.edit().putInt("customX", v).apply() }

    var customY: Int
        get() = sp.getInt("customY", 24)
        set(v) { sp.edit().putInt("customY", v).apply() }

    // ---- floating lyrics + top pill
    var floatLyrics: Boolean
        get() = sp.getBoolean("floatLyrics", true)
        set(v) { sp.edit().putBoolean("floatLyrics", v).apply() }

    var topPill: Boolean
        get() = sp.getBoolean("topPill", true)
        set(v) { sp.edit().putBoolean("topPill", v).apply() }

    var floatCaps: Boolean
        get() = sp.getBoolean("floatCaps", true)
        set(v) { sp.edit().putBoolean("floatCaps", v).apply() }

    var floatAccent: Boolean
        get() = sp.getBoolean("floatAccent", false)
        set(v) { sp.edit().putBoolean("floatAccent", v).apply() }

    /** percent 50..200 */
    var floatSize: Int
        get() = sp.getInt("floatSize", 100)
        set(v) { sp.edit().putInt("floatSize", v).apply() }

    var floatFont: Int
        get() = sp.getInt("floatFont", 1)
        set(v) { sp.edit().putInt("floatFont", v).apply() }

    var floatShadow: Int
        get() = sp.getInt("floatShadow", 1)
        set(v) { sp.edit().putInt("floatShadow", v).apply() }

    // ---- 3D lyrics (Lyrics Plus 3D add-on via /wsserver)
    var w3dOn: Boolean
        get() = sp.getBoolean("w3dOn", true)
        set(v) { sp.edit().putBoolean("w3dOn", v).apply() }

    /** percent 50..250 */
    var w3dSize: Int
        get() = sp.getInt("w3dSize", 100)
        set(v) { sp.edit().putInt("w3dSize", v).apply() }

    /** blocks in front of the player, 3..14 */
    var w3dDist: Int
        get() = sp.getInt("w3dDist", 6)
        set(v) { sp.edit().putInt("w3dDist", v).apply() }

    var w3dFollow: Boolean
        get() = sp.getBoolean("w3dFollow", true)
        set(v) { sp.edit().putBoolean("w3dFollow", v).apply() }
}
