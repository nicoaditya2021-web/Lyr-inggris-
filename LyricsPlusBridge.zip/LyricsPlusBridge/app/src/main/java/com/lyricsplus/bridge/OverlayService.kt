package com.lyricsplus.bridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.WindowManager

/** Foreground service: draws the panel over Minecraft and runs the local bridge server. */
class OverlayService : Service() {

    companion object {
        const val ACTION_RELOAD = "com.lyricsplus.bridge.RELOAD"
        const val ACTION_STOP = "com.lyricsplus.bridge.STOP"
        @Volatile var running = false
        @Volatile var wsConnected = false
        private const val CH = "lp_bridge"
        private const val NID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var st: Settings
    private var panel: PanelView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var attached = false
    private var floatView: FloatView? = null
    private var floatAttached = false
    private var server: LocalServer? = null
    private var ws: WsBridge? = null
    private var wasConn = false
    private var lastCfg = ""
    private var lastKey = ""
    private var lastPlaying: Boolean? = null
    private val handler = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 300)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        st = Settings(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        server = LocalServer().also { it.start() }
        ws = WsBridge().also { it.start() }
        running = true
        buildPanel()
        handler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> buildPanel()
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        removePanel()
        server?.stop()
        ws?.stop()
        running = false
        wsConnected = false
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Lyrics Plus Bridge", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Lyrics Plus Bridge")
            .setContentText("Music panel active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun makeParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        val m = (12 * resources.displayMetrics.density).toInt()
        when (st.position) {
            0 -> { p.gravity = Gravity.TOP or Gravity.START; p.x = m; p.y = m }
            1 -> { p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = m }
            2 -> { p.gravity = Gravity.TOP or Gravity.END; p.x = m; p.y = m }
            3 -> { p.gravity = Gravity.BOTTOM or Gravity.START; p.x = m; p.y = m }
            4 -> { p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = m }
            5 -> { p.gravity = Gravity.BOTTOM or Gravity.END; p.x = m; p.y = m }
            else -> { p.gravity = Gravity.TOP or Gravity.START; p.x = st.customX; p.y = st.customY }
        }
        return p
    }

    private fun buildPanel() {
        removePanel()
        lastCfg = ""
        lp = makeParams()
        panel = PanelView(this, st, ::onDragBy, ::onDragEnd, ::onHidden)
        floatView = FloatView(this, st)
    }

    private fun makeFloatParams(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun removePanel() {
        val pv = panel
        if (pv != null && attached) {
            try { wm.removeView(pv) } catch (_: Exception) {}
        }
        attached = false
        panel = null
        val fv = floatView
        if (fv != null && floatAttached) {
            try { wm.removeView(fv) } catch (_: Exception) {}
        }
        floatAttached = false
        floatView = null
    }

    private fun onHidden() {
        val pv = panel ?: return
        if (attached) {
            try { wm.removeView(pv) } catch (_: Exception) {}
            attached = false
        }
    }

    private fun onDragBy(dx: Int, dy: Int) {
        val p = lp ?: return
        val pv = panel ?: return
        if (st.position != 6) {
            val loc = IntArray(2)
            pv.getLocationOnScreen(loc)
            p.gravity = Gravity.TOP or Gravity.START
            p.x = loc[0]
            p.y = loc[1]
            st.position = 6
        }
        val dm = resources.displayMetrics
        p.x = (p.x + dx).coerceIn(0, maxOf(0, dm.widthPixels - pv.width))
        p.y = (p.y + dy).coerceIn(0, maxOf(0, dm.heightPixels - pv.height))
        try { wm.updateViewLayout(pv, p) } catch (_: Exception) {}
    }

    private fun onDragEnd() {
        val p = lp ?: return
        st.customX = p.x
        st.customY = p.y
    }

    private fun trunc(s: String, maxBytes: Int): String {
        val b = s.toByteArray(Charsets.UTF_8)
        if (b.size <= maxBytes) return s
        var n = maxBytes
        while (n > 0 && (b[n].toInt() and 0xC0) == 0x80) n--
        return String(b, 0, n, Charsets.UTF_8)
    }

    private fun cfgString() = "on=${if (st.w3dOn) 1 else 0};size=${st.w3dSize};dist=${st.w3dDist};" +
            "caps=${if (st.floatCaps) 1 else 0};follow=${if (st.w3dFollow) 1 else 0}"

    /** Sends lyric events to the Minecraft add-on (only while Minecraft is connected via /wsserver). */
    private fun pushToMinecraft() {
        val w = ws ?: return
        val conn = w.connected
        wsConnected = conn
        if (!conn) { wasConn = false; return }
        if (!wasConn) { wasConn = true; lastCfg = ""; lastKey = ""; lastPlaying = null }

        val cfg = cfgString()
        if (cfg != lastCfg) { lastCfg = cfg; w.sendCommand("scriptevent lyricsplus:cfg $cfg") }

        val playing = MediaState.playing
        if (playing != lastPlaying) {
            lastPlaying = playing
            w.sendCommand("scriptevent lyricsplus:p ${if (playing) 1 else 0}")
        }
        val lines = LyricsRepo.lines
        if (!st.w3dOn || !playing || MediaState.track == null || lines.isEmpty()) return
        val pos = MediaState.position()
        val idx = LyricsRepo.indexAt(pos)
        val key = "${MediaState.trackId}:$idx"
        if (key == lastKey) return
        lastKey = key
        if (idx < 0) return
        val line = lines[idx]
        val next = lines.getOrNull(idx + 1)?.t ?: (line.t + 4000)
        val dur = (next - line.t).coerceIn(1200L, 8000L)
        val elapsed = (pos - line.t).coerceIn(0L, dur)
        val text = trunc(line.text.replace(Regex("[\\r\\n]+"), " ").trim(), 300)
        if (text.isEmpty()) return
        w.sendCommand("scriptevent lyricsplus:l $elapsed|$dur|$text")
    }

    private fun tick() {
        pushToMinecraft()
        val tr = MediaState.track
        if (st.lyrics && tr != null) LyricsRepo.ensure(tr, MediaState.trackId)

        val wantFloat = (st.floatLyrics || st.topPill) && st.lyrics && tr != null &&
                AndroidSettings.canDrawOverlays(this)
        val fv = floatView
        if (fv != null) {
            if (wantFloat && !floatAttached) {
                try { wm.addView(fv, makeFloatParams()); floatAttached = true } catch (_: Exception) {}
            } else if (!wantFloat && floatAttached) {
                try { wm.removeView(fv) } catch (_: Exception) {}
                floatAttached = false
            }
        }

        val want = st.musicUi && tr != null
        val pv = panel ?: return
        if (want && !attached && AndroidSettings.canDrawOverlays(this)) {
            try {
                wm.addView(pv, lp)
                attached = true
            } catch (_: Exception) {
            }
        }
        pv.setTargetShown(want)
    }
}
