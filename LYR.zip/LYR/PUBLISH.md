# Build dan publish LYR

## Cara cepat (tanpa PC, lewat GitHub)
1. Upload `LYR.zip` (jangan di-extract) ke root repo, dan `build.yml` ke `.github/workflows/build.yml`.
   Kalau repo masih punya `LyricsPlusBridge.zip` lama, hapus supaya tidak tertukar.
2. Tab **Actions** > *Build LYR* > Run workflow. Hasil: artifact `LYR` berisi `LYR.apk` dan `LYR.mcaddon`.
3. Link unduhan publik: buat release dengan tag `v1.0.0`. Workflow melampirkan kedua file di halaman Release.

## Tanda tangan (disarankan sebelum dibagikan luas)
Tanpa kunci sendiri, APK ditandatangani dengan debug key. Bisa dipasang, tapi update dari build lain bisa gagal.
1. `keytool -genkey -v -keystore release.jks -alias lyr -keyalg RSA -keysize 2048 -validity 10000`
2. `base64 -w0 release.jks`
3. Repo > Settings > Secrets and variables > Actions: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
4. Naikkan `versionCode` dan `versionName` di `app/build.gradle.kts` tiap rilis.

## Catatan
- APK memakai id `com.lyr.app`, jadi bisa dipasang berdampingan dengan versi lama (Lyrics Plus).
- Pasang `LYR.mcaddon` di Minecraft, aktifkan BP dan RP di dunia, lalu ketik `/wsserver ws://127.0.0.1:8765`.
- Play Store butuh AAB dan review kebijakan (akses notifikasi dan overlay dinilai ketat). Belum disiapkan.
