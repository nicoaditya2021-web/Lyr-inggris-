// Minimal offline stand-in for @minecraft/server, with a voxel world and a movable player.
export const state = { tick: 0, intervals: [], subs: [], particles: [], entities: [], solid: () => false };

export class MolangVariableMap {
    constructor() { this.vars = {}; }
    setFloat(k, v) { this.vars[k] = v; }
}

export const system = {
    get currentTick() { return state.tick; },
    runInterval(fn, n) { state.intervals.push({ fn, n, next: state.tick + n }); return state.intervals.length; },
    run(fn) { fn(); },
    runTimeout(fn) { fn(); return 0; },
    clearRun() {},
    afterEvents: { scriptEventReceive: { subscribe(cb) { state.subs.push(cb); } } },
};

function floor(v) { return Math.floor(v); }

export function makeDim() {
    return {
        id: "overworld",
        spawnParticle(id, loc, map) { state.particles.push({ id, loc: { ...loc }, vars: { ...map.vars }, tick: state.tick }); },
        spawnEntity(id, loc) { const e = { id, nameTag: "", loc: { ...loc }, removed: false, teleport(p) { e.loc = { ...p }; }, remove() { e.removed = true; } }; state.entities.push(e); return e; },
        getEntities() { return []; },
        getBlock(l) { const x = floor(l.x), y = floor(l.y), z = floor(l.z); const s = state.solid(x, y, z); return { isSolid: s, isAir: !s, isLiquid: false, location: { x, y, z } }; },
        getBlockFromRay(o, d, opt) {
            const max = opt.maxDistance ?? 10;
            let x = floor(o.x), y = floor(o.y), z = floor(o.z);
            if (state.solid(x, y, z)) return { block: { location: { x, y, z } } };
            const sx = Math.sign(d.x), sy = Math.sign(d.y), sz = Math.sign(d.z);
            const tD = (p, dd, s, c) => (dd === 0 ? Infinity : ((s > 0 ? c + 1 : c) - p) / dd);
            let tx = tD(o.x, d.x, sx, x), ty = tD(o.y, d.y, sy, y), tz = tD(o.z, d.z, sz, z);
            const dx = d.x === 0 ? Infinity : Math.abs(1 / d.x), dy = d.y === 0 ? Infinity : Math.abs(1 / d.y), dz = d.z === 0 ? Infinity : Math.abs(1 / d.z);
            let t = 0;
            while (t <= max) {
                if (tx <= ty && tx <= tz) { x += sx; t = tx; tx += dx; }
                else if (ty <= tz) { y += sy; t = ty; ty += dy; }
                else { z += sz; t = tz; tz += dz; }
                if (t > max) break;
                if (state.solid(x, y, z)) return { block: { location: { x, y, z } } };
            }
            return undefined;
        },
    };
}

export function makePlayer(dim) {
    const P = {
        typeId: "minecraft:player", isValid: true, dimension: dim, x: 0, y: 64, z: 0, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0,
        getHeadLocation() { return { x: P.x, y: P.y + 1.62, z: P.z }; },
        getViewDirection() {
            const cp = Math.cos(P.pitch);
            return { x: -Math.sin(P.yaw) * cp, y: -Math.sin(P.pitch), z: Math.cos(P.yaw) * cp };
        },
        getVelocity() { return { x: P.vx, y: P.vy, z: P.vz }; },
        sendMessage() {},
    };
    return P;
}

export const world = {
    players: [],
    getAllPlayers() { return world.players; },
    getDimension() { return world.dim; },
};

export function advance() {
    state.tick++;
    for (const i of state.intervals) if (state.tick >= i.next) { i.fn(); i.next += i.n; }
}
export function send(id, message, player) {
    for (const cb of state.subs) cb({ id, message, sourceEntity: player });
}
