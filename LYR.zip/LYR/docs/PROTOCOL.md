# Local bridge (127.0.0.1:38417, loopback only)
Dipakai mod native / program lokal lain untuk membaca data dan mengirim kontrol.

| Method | Path | Hasil |
|---|---|---|
| GET | /status | `{"status":"ok","mod":"LYR"}` |
| GET | /state | JSON: hasTrack, title, artist, album, durationMs, positionMs, playing, package, trackId, hasCover, lyricsStatus, lyricIndex, lyricPrev, lyricCurrent, lyricNext |
| GET | /cover.jpg | cover JPEG (404 jika tidak ada) |
| GET/POST | /cmd/toggle, /cmd/play, /cmd/pause, /cmd/next, /cmd/prev | `{"ok":true}` |
| GET/POST | /seek?ms=12345 | `{"ok":true}` |

Mod C++ cukup polling `/state` (mis. 4x/detik) dan menggambar UI sendiri.
