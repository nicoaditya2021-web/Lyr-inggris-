package com.lyricsplus.bridge

import android.content.Context
import android.graphics.Typeface

/** Bundled fonts (SIL Open Font License) - same fonts are baked into the add-on's glyph atlases. */
object Fonts {
    val NAMES = listOf(
        "Outfit", "Bricolage", "Erica One", "Gloock",
        "Lora Italic", "Handwritten", "Big Shoulders", "Pixelify"
    )
    private val cache = arrayOfNulls<Typeface>(NAMES.size)

    fun get(ctx: Context, i: Int): Typeface {
        val k = i.coerceIn(0, NAMES.size - 1)
        val hit = cache[k]
        if (hit != null) return hit
        val t = try {
            Typeface.createFromAsset(ctx.applicationContext.assets, "fonts/f$k.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT_BOLD
        }
        cache[k] = t
        return t
    }
}
