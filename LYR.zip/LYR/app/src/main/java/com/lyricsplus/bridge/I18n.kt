package com.lyricsplus.bridge

import android.content.Context
import java.util.Locale

/**
 * Two languages: Indonesian (the source strings in the code) and English.
 * Every visible text goes through tr(); in English mode it is looked up in EnStrings.MAP, anything missing stays as is.
 */
object I18n {
    var en = false
        private set

    /** mode: 0 follow the phone's language, 1 Indonesian, 2 English */
    fun init(ctx: Context, mode: Int) {
        en = when (mode) {
            1 -> false
            2 -> true
            else -> {
                val l = Locale.getDefault().language
                !(l == "in" || l == "id")
            }
        }
    }

    fun tr(s: String): String = if (en) (EnStrings.MAP[s] ?: s) else s

    /** translated template with %s / %d placeholders */
    fun trf(template: String, vararg args: Any): String = String.format(tr(template), *args)
}
