package com.lyricsplus.bridge

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/** Blue + white theme with light and dark variants (iOS-like grouped look). */
object T {
    var dark = true

    val bg: Int get() = if (dark) 0xFF070B14.toInt() else 0xFFF2F6FD.toInt()
    val card: Int get() = if (dark) 0xFF111A2C.toInt() else 0xFFFFFFFF.toInt()
    val text: Int get() = if (dark) 0xFFF4F7FF.toInt() else 0xFF0A1630.toInt()
    val sub: Int get() = if (dark) 0xFF8E9CBA.toInt() else 0xFF6B7794.toInt()
    val line: Int get() = if (dark) 0x22FFFFFF else 0x1A0A1630
    val fill: Int get() = if (dark) 0x26FFFFFF else 0x140A1630
    val accent: Int get() = if (dark) 0xFF4DA3FF.toInt() else 0xFF0A84FF.toInt()
    val accentSoft: Int get() = (accent and 0x00FFFFFF) or 0x24000000
    val segSel: Int get() = if (dark) 0xFF34405E.toInt() else 0xFFFFFFFF.toInt()
    val segBg: Int get() = if (dark) 0xFF0B1220.toInt() else 0xFFE6ECF7.toInt()
    val switchOff: Int get() = if (dark) 0xFF2A3550.toInt() else 0xFFD5DCEB.toInt()
    val green: Int = 0xFF34C759.toInt()
    val red: Int = 0xFFFF453A.toInt()
    val orange: Int = 0xFFFF9F0A.toInt()

    fun systemDark(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** mode: 0 follow system, 1 light, 2 dark */
    fun resolve(ctx: Context, mode: Int) {
        dark = when (mode) {
            1 -> false
            2 -> true
            else -> systemDark(ctx)
        }
    }

    fun rr(color: Int, radiusPx: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radiusPx
        return g
    }

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val al = (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt()
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        return Color.argb(al, r, g, bl)
    }
}
