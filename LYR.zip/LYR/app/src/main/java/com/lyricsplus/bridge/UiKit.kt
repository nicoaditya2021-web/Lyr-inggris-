package com.lyricsplus.bridge

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ============================================================================ iOS-style switch
class IosSwitch(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var t = 0f
    private var on = false
    private var anim: ValueAnimator? = null
    var onChange: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { toggle() }
    }

    fun isOn(): Boolean = on

    fun setChecked(v: Boolean, animate: Boolean) {
        on = v
        anim?.cancel()
        if (!animate) {
            t = if (v) 1f else 0f
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(t, if (v) 1f else 0f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun toggle() {
        setChecked(!on, true)
        onChange?.invoke(on)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((51 * d).toInt(), (31 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = T.mix(T.switchOff, T.accent, t)
        rf.set(0f, 0f, w, h)
        c.drawRoundRect(rf, h / 2, h / 2, p)
        val r = h / 2 - 2 * d
        val cx = h / 2 + (w - h) * t
        p.color = 0x33000000
        c.drawCircle(cx, h / 2 + 1.5f * d, r, p)
        p.color = Color.WHITE
        c.drawCircle(cx, h / 2, r, p)
    }
}

// ============================================================================ floating tab bar
class TabBar(ctx: Context, private val labels: List<String>, private val onSelect: (Int) -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val path = Path()
    private var pos = 0f
    private var anim: ValueAnimator? = null
    var selected = 0
        private set
    var badgeAt = -1

    init {
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = 10.5f * d
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        ip.style = Paint.Style.STROKE
        ip.strokeCap = Paint.Cap.ROUND
        ip.strokeJoin = Paint.Join.ROUND
        ip.strokeWidth = 1.8f * d
    }

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        anim?.cancel()
        anim = ValueAnimator.ofFloat(pos, i.toFloat()).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            onSelect(i)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 6f * d
        // shadow + body
        p.style = Paint.Style.FILL
        p.color = if (T.dark) 0x55000000 else 0x1A0A1630
        rf.set(3f * d, 5f * d, w - 3f * d, h - 1f * d)
        c.drawRoundRect(rf, h / 2, h / 2, p)
        p.color = (T.card and 0x00FFFFFF) or 0xF4000000.toInt()
        rf.set(2f * d, 2f * d, w - 2f * d, h - 4f * d)
        val bh = rf.height()
        c.drawRoundRect(rf, bh / 2, bh / 2, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = T.line
        c.drawRoundRect(rf, bh / 2, bh / 2, p)
        p.style = Paint.Style.FILL

        val n = labels.size
        val tabW = (w - 2 * pad - 4 * d) / n
        val left0 = pad + 2 * d
        // sliding pill
        p.color = T.accentSoft
        val pl = left0 + pos * tabW
        rf.set(pl + 2 * d, rf.top + 5 * d, pl + tabW - 2 * d, rf.bottom - 5 * d)
        c.drawRoundRect(rf, rf.height() / 2, rf.height() / 2, p)

        for (i in 0 until n) {
            val cx = left0 + tabW * (i + 0.5f)
            val sel = 1f - min(1f, abs(i - pos))
            val col = T.mix(T.sub, T.accent, sel)
            ip.color = col
            icon(c, i, cx, h * 0.36f, 9.5f * d)
            tp.color = col
            c.drawText(labels[i], cx, h * 0.74f, tp)
            if (i == badgeAt) {
                p.color = T.red
                c.drawCircle(cx + 11f * d, h * 0.36f - 9f * d, 4f * d, p)
            }
        }
    }

    private fun icon(c: Canvas, i: Int, cx: Float, cy: Float, s: Float) {
        path.reset()
        when (i) {
            0 -> { // house
                path.moveTo(cx - 0.9f * s, cy + 0.1f * s); path.lineTo(cx, cy - 0.85f * s); path.lineTo(cx + 0.9f * s, cy + 0.1f * s)
                path.moveTo(cx - 0.65f * s, cy - 0.1f * s); path.lineTo(cx - 0.65f * s, cy + 0.85f * s)
                path.lineTo(cx + 0.65f * s, cy + 0.85f * s); path.lineTo(cx + 0.65f * s, cy - 0.1f * s)
                path.moveTo(cx - 0.2f * s, cy + 0.85f * s); path.lineTo(cx - 0.2f * s, cy + 0.3f * s)
                path.lineTo(cx + 0.2f * s, cy + 0.3f * s); path.lineTo(cx + 0.2f * s, cy + 0.85f * s)
            }
            1 -> { // cube
                path.moveTo(cx, cy - 0.9f * s); path.lineTo(cx + 0.8f * s, cy - 0.45f * s); path.lineTo(cx + 0.8f * s, cy + 0.45f * s)
                path.lineTo(cx, cy + 0.9f * s); path.lineTo(cx - 0.8f * s, cy + 0.45f * s); path.lineTo(cx - 0.8f * s, cy - 0.45f * s)
                path.close()
                path.moveTo(cx - 0.8f * s, cy - 0.45f * s); path.lineTo(cx, cy); path.lineTo(cx + 0.8f * s, cy - 0.45f * s)
                path.moveTo(cx, cy); path.lineTo(cx, cy + 0.9f * s)
            }
            2 -> { // music note
                path.addCircle(cx - 0.35f * s, cy + 0.55f * s, 0.3f * s, Path.Direction.CW)
                path.moveTo(cx - 0.05f * s, cy + 0.55f * s); path.lineTo(cx - 0.05f * s, cy - 0.8f * s)
                path.cubicTo(cx + 0.25f * s, cy - 0.5f * s, cx + 0.75f * s, cy - 0.5f * s, cx + 0.6f * s, cy + 0.05f * s)
            }
            3 -> { // chat bubble
                rf.set(cx - 0.9f * s, cy - 0.75f * s, cx + 0.9f * s, cy + 0.45f * s)
                path.addRoundRect(rf, 0.35f * s, 0.35f * s, Path.Direction.CW)
                path.moveTo(cx - 0.3f * s, cy + 0.45f * s); path.lineTo(cx - 0.5f * s, cy + 0.9f * s); path.lineTo(cx + 0.05f * s, cy + 0.45f * s)
            }
            else -> { // sliders
                path.moveTo(cx - 0.85f * s, cy - 0.5f * s); path.lineTo(cx - 0.15f * s, cy - 0.5f * s)
                path.moveTo(cx + 0.45f * s, cy - 0.5f * s); path.lineTo(cx + 0.85f * s, cy - 0.5f * s)
                path.addCircle(cx + 0.15f * s, cy - 0.5f * s, 0.28f * s, Path.Direction.CW)
                path.moveTo(cx - 0.85f * s, cy + 0.5f * s); path.lineTo(cx - 0.45f * s, cy + 0.5f * s)
                path.moveTo(cx + 0.15f * s, cy + 0.5f * s); path.lineTo(cx + 0.85f * s, cy + 0.5f * s)
                path.addCircle(cx - 0.15f * s, cy + 0.5f * s, 0.28f * s, Path.Direction.CW)
            }
        }
        c.drawPath(path, ip)
    }
}

// ============================================================================ transport buttons
class TransportBtn(ctx: Context, private val kind: Int) : View(ctx) {
    companion object { const val PREV = 0; const val PLAY = 1; const val NEXT = 2 }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    var playing = false
        set(v) { if (field != v) { field = v; invalidate() } }

    init {
        isClickable = true
        setOnTouchListener { vv, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) vv.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) vv.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            false
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        path.reset()
        if (kind == PLAY) {
            p.color = T.accent
            c.drawCircle(cx, cy, r, p)
            p.color = Color.WHITE
            if (playing) {
                rf.set(cx - r * 0.3f, cy - r * 0.34f, cx - r * 0.08f, cy + r * 0.34f)
                c.drawRoundRect(rf, r * 0.06f, r * 0.06f, p)
                rf.set(cx + r * 0.08f, cy - r * 0.34f, cx + r * 0.3f, cy + r * 0.34f)
                c.drawRoundRect(rf, r * 0.06f, r * 0.06f, p)
            } else {
                path.moveTo(cx - r * 0.2f, cy - r * 0.36f)
                path.lineTo(cx - r * 0.2f, cy + r * 0.36f)
                path.lineTo(cx + r * 0.38f, cy)
                path.close()
                c.drawPath(path, p)
            }
        } else {
            p.color = T.text
            val s = r * 0.5f
            val dir = if (kind == NEXT) 1f else -1f
            // two triangles
            for (k in 0..1) {
                val x0 = cx + dir * (k * s * 0.85f - s * 0.45f)
                path.moveTo(x0 - dir * s * 0.45f, cy - s * 0.6f)
                path.lineTo(x0 - dir * s * 0.45f, cy + s * 0.6f)
                path.lineTo(x0 + dir * s * 0.45f, cy)
                path.close()
            }
            c.drawPath(path, p)
        }
    }
}

// ============================================================================ seek bar
class ProgressBarView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var frac = 0f
    private var dragging = false
    var onSeek: ((Float) -> Unit)? = null

    fun setProgress(f: Float) {
        if (dragging) return
        frac = f.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                frac = (e.x / max(1f, width.toFloat())).coerceIn(0f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                onSeek?.invoke(frac)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val th = 4f * d
        val y = h / 2
        p.color = T.fill
        rf.set(0f, y - th / 2, w, y + th / 2)
        c.drawRoundRect(rf, th / 2, th / 2, p)
        p.color = T.accent
        rf.set(0f, y - th / 2, w * frac, y + th / 2)
        c.drawRoundRect(rf, th / 2, th / 2, p)
        val tr = if (dragging) 8f * d else 6f * d
        p.color = T.accent
        c.drawCircle(w * frac, y, tr, p)
    }
}

// ============================================================================ morphing cover (inspired by the reference)
class MorphCover(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val m = Matrix()
    private var shader: BitmapShader? = null
    private var t0 = SystemClock.uptimeMillis()
    var animated = true
    var bmp: Bitmap? = null
        set(v) {
            if (field !== v) {
                field = v
                shader = if (v != null) BitmapShader(v, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) else null
                invalidate()
            }
        }

    private val frame = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (isShown && animated) invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(frame); post(frame) }
    override fun onDetachedFromWindow() { removeCallbacks(frame); super.onDetachedFromWindow() }

    private fun shape(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, rad: Float, rot: Float, alpha: Int) {
        c.save()
        c.translate(cx, cy)
        c.rotate(rot)
        rect.set(-w / 2, -h / 2, w / 2, h / 2)
        val b = bmp
        val sh = shader
        if (b != null && sh != null) {
            val sc = max(w / b.width, h / b.height)
            m.reset()
            m.setScale(sc, sc)
            m.postTranslate(-b.width * sc / 2f, -b.height * sc / 2f)
            sh.setLocalMatrix(m)
            paint.shader = sh
        } else {
            paint.shader = LinearGradient(-w / 2, -h / 2, w / 2, h / 2, 0xFF7CC8FF.toInt(), 0xFF0A84FF.toInt(), Shader.TileMode.CLAMP)
        }
        paint.alpha = alpha
        c.drawRoundRect(rect, rad, rad, paint)
        paint.shader = null
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val t = if (animated) (SystemClock.uptimeMillis() - t0) / 1000f else 0f
        val cx = width / 2f
        val cy = height / 2f
        val main = min(width * 0.46f, height * 0.78f)
        val k = (sin(t * 0.9f) + 1f) / 2f
        val rad = main * (0.2f + 0.3f * k)
        val rot = -16f + 12f * sin(t * 0.5f)
        // small floating "bubbles" like the reference
        val b1 = main * 0.34f
        val b2 = main * 0.3f
        shape(c, cx - main * 0.82f, cy - main * 0.36f + 6f * d * sin(t * 1.1f), b1, b1, b1 / 2, 0f, 235)
        shape(c, cx + main * 0.8f, cy + main * 0.4f + 6f * d * sin(t * 1.3f + 1f), b2, b2, b2 / 2, 0f, 235)
        shape(c, cx, cy, main * (1f + 0.22f * k), main * (1f - 0.1f * k), rad, rot, 255)
    }
}

// ============================================================================ builders
class Kit(val ctx: Context, val st: Settings, private val onChange: () -> Unit) {
    val d: Float = ctx.resources.displayMetrics.density
    fun dp(v: Int): Int = (v * d).toInt()
    fun dpf(v: Float): Float = v * d
    fun lp(w: Int, h: Int, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = dp(bottom) }

    fun tv(text: String, sp: Float, color: Int = T.text, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = I18n.tr(text)
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        return t
    }

    fun pressDim(v: View) {
        v.setOnTouchListener { vv, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) vv.animate().alpha(0.55f).setDuration(80).start()
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) vv.animate().alpha(1f).setDuration(160).start()
            false
        }
    }

    fun round(v: View, radiusDp: Float) {
        val r = radiusDp * d
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, r) }
        }
        v.clipToOutline = true
    }

    fun circle(v: View) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setOval(0, 0, view.width, view.height) }
        }
        v.clipToOutline = true
    }

    /** avatar with a ring that matches the background so stacked avatars separate nicely */
    fun avatar(res: Int, sizeDp: Int, ring: Int = T.bg): View {
        val wrap = FrameLayout(ctx)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(ring)
        wrap.background = bg
        wrap.setPadding(dp(2), dp(2), dp(2), dp(2))
        val iv = ImageView(ctx)
        iv.setImageResource(res)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        circle(iv)
        wrap.addView(iv, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)))
        return wrap
    }

    fun page(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        sv.addView(col, FrameLayout.LayoutParams(-1, -2))
        return Pair(sv, col)
    }

    fun title(col: LinearLayout, big: String, small: String, trailing: View? = null) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val tx = LinearLayout(ctx)
        tx.orientation = LinearLayout.VERTICAL
        val t = tv(big, 34f, T.text, false)
        t.setTypeface(Fonts.get(ctx, 0), Typeface.BOLD)
        tx.addView(t)
        tx.addView(tv(small, 14f, T.sub))
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) row.addView(trailing)
        col.addView(row, lp(-1, -2, 4))
    }

    /** iOS-style rounded group. Returns the container that rows are added to. */
    fun section(col: LinearLayout, label: String?): LinearLayout {
        if (label != null) {
            val l = tv(label, 13f, T.sub)
            l.setPadding(dp(16), 0, 0, dp(6))
            col.addView(l, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        } else {
            col.addView(View(ctx), LinearLayout.LayoutParams(-1, dp(14)))
        }
        val g = LinearLayout(ctx)
        g.orientation = LinearLayout.VERTICAL
        g.background = T.rr(T.card, dpf(18f))
        if (!T.dark) g.elevation = dpf(1f)
        col.addView(g, LinearLayout.LayoutParams(-1, -2))
        return g
    }

    fun footnote(col: LinearLayout, text: String) {
        val l = tv(text, 12f, T.sub)
        l.setPadding(dp(16), dp(6), dp(16), 0)
        col.addView(l, LinearLayout.LayoutParams(-1, -2))
    }

    /** adds a row to a group, with a hairline divider above it (except the first) */
    fun add(g: LinearLayout, row: View): View {
        if (g.childCount > 0) {
            val dv = View(ctx)
            dv.setBackgroundColor(T.line)
            g.addView(dv, LinearLayout.LayoutParams(-1, max(1, (d / 2f).toInt())).apply { leftMargin = dp(16) })
        }
        g.addView(row, LinearLayout.LayoutParams(-1, -2))
        return row
    }

    private fun baseRow(): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(11), dp(16), dp(11))
        r.minimumHeight = dp(50)
        return r
    }

    /** custom content inside a group, with standard padding */
    fun custom(g: LinearLayout, v: View, h: Int = -2) {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(12))
        r.addView(v, LinearLayout.LayoutParams(-1, h))
        add(g, r)
    }

    fun rowText(g: LinearLayout, title: String, sub: String?, trailing: View?): LinearLayout {
        val r = baseRow()
        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(title, 16f))
        if (sub != null) left.addView(tv(sub, 12.5f, T.sub))
        r.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        add(g, r)
        return r
    }

    fun rowSwitch(g: LinearLayout, title: String, sub: String?, get: () -> Boolean, set: (Boolean) -> Unit): IosSwitch {
        val sw = IosSwitch(ctx)
        sw.setChecked(get(), false)
        sw.onChange = { set(it); onChange() }
        val r = rowText(g, title, sub, sw)
        r.setOnClickListener { sw.toggle() }
        pressDim(r)
        return sw
    }

    /** read-only value row; returns the value label for live updates */
    fun rowInfo(g: LinearLayout, title: String, value: String): TextView {
        val v = tv(value, 15f, T.sub)
        v.gravity = Gravity.END
        v.maxLines = 2
        rowText(g, title, null, v)
        return v
    }

    /** status row with a colored value; optional tap action */
    fun rowStatus(g: LinearLayout, title: String, onClick: (() -> Unit)?): TextView {
        val v = tv("", 15f, T.sub, true)
        v.gravity = Gravity.END
        val r = rowText(g, title, null, v)
        if (onClick != null) {
            r.setOnClickListener { onClick() }
            pressDim(r)
        }
        return v
    }

    fun setStatus(v: TextView, text: String, color: Int) {
        val tt = I18n.tr(text)
        if (v.text.toString() != tt) v.text = tt
        v.setTextColor(color)
    }

    fun rowButton(g: LinearLayout, title: String, color: Int = T.accent, onClick: () -> Unit): TextView {
        val t = tv(title, 16f, color)
        val r = baseRow()
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        r.setOnClickListener { onClick() }
        pressDim(r)
        add(g, r)
        return t
    }

    fun rowNav(g: LinearLayout, title: String, sub: String?, onClick: () -> Unit) {
        val chev = tv("\u203A", 24f, T.sub)
        val r = rowText(g, title, sub, chev)
        r.setOnClickListener { onClick() }
        pressDim(r)
    }

    fun rowSlider(g: LinearLayout, title: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(tv(title, 16f), LinearLayout.LayoutParams(0, -2, 1f))
        val value = tv("${get()}", 15f, T.accent, true)
        head.addView(value)
        box.addView(head)
        val sb = SeekBar(ctx)
        sb.max = max - min
        sb.progress = get() - min
        sb.progressTintList = ColorStateList.valueOf(T.accent)
        sb.thumbTintList = ColorStateList.valueOf(T.accent)
        sb.progressBackgroundTintList = ColorStateList.valueOf(T.fill)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = "${p + min}" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                set((s?.progress ?: 0) + min)
                onChange()
            }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        custom(g, box)
    }

    /** 2-3 options become a segmented control, more options become scrolling chips */
    fun rowChoice(
        g: LinearLayout, title: String, names: List<String>, get: () -> Int, set: (Int) -> Unit,
        face: ((Int) -> Typeface)? = null, dots: List<Int>? = null
    ) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.addView(tv(title, 16f), lp(-2, -2, 10))
        if (names.size <= 3 && face == null && dots == null) {
            val seg = LinearLayout(ctx)
            seg.orientation = LinearLayout.HORIZONTAL
            seg.background = T.rr(T.segBg, dpf(11f))
            seg.setPadding(dp(2), dp(2), dp(2), dp(2))
            val cells = ArrayList<TextView>()
            fun paint(sel: Int) {
                for ((j, c) in cells.withIndex()) {
                    if (j == sel) {
                        c.background = T.rr(T.segSel, dpf(9f))
                        c.setTextColor(T.text)
                    } else {
                        c.background = null
                        c.setTextColor(T.sub)
                    }
                }
            }
            for ((i, n) in names.withIndex()) {
                val c = tv(n, 13.5f, T.sub, true)
                c.gravity = Gravity.CENTER
                c.setPadding(dp(6), dp(8), dp(6), dp(8))
                c.setOnClickListener { set(i); paint(i); onChange() }
                cells.add(c)
                seg.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            }
            paint(get())
            box.addView(seg, LinearLayout.LayoutParams(-1, -2))
        } else {
            val hs = HorizontalScrollView(ctx)
            hs.isHorizontalScrollBarEnabled = false
            val rowL = LinearLayout(ctx)
            rowL.orientation = LinearLayout.HORIZONTAL
            val chips = ArrayList<TextView>()
            fun paint(sel: Int) {
                for ((j, c) in chips.withIndex()) {
                    if (j == sel) {
                        c.background = T.rr(T.accent, dpf(18f))
                        c.setTextColor(Color.WHITE)
                    } else {
                        c.background = T.rr(T.fill, dpf(18f))
                        c.setTextColor(T.text)
                    }
                }
            }
            for ((i, n) in names.withIndex()) {
                val c = tv(n, 14f, T.text, false)
                c.setPadding(dp(16), dp(9), dp(16), dp(9))
                if (dots != null) {
                    val sp = SpannableString("\u25CF  " + I18n.tr(n))
                    sp.setSpan(ForegroundColorSpan(dots[i] or (0xFF shl 24)), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    c.text = sp
                }
                if (face != null) {
                    c.typeface = face(i)
                    c.textSize = 17f
                }
                c.setOnClickListener { set(i); paint(i); onChange() }
                chips.add(c)
                rowL.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
            }
            paint(get())
            hs.addView(rowL)
            box.addView(hs, LinearLayout.LayoutParams(-1, -2))
        }
        custom(g, box)
    }

    /** small tinted pill button */
    fun pill(text: String, onClick: () -> Unit): TextView {
        val t = tv(text, 14f, T.accent, true)
        t.setPadding(dp(16), dp(9), dp(16), dp(9))
        t.background = T.rr(T.accentSoft, dpf(18f))
        t.setOnClickListener { onClick() }
        pressDim(t)
        return t
    }

    fun pillRow(g: LinearLayout, pills: List<TextView>) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        for ((i, p) in pills.withIndex()) {
            row.addView(p, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = dp(8) })
        }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        custom(g, hs)
    }
}
