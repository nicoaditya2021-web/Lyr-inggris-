package com.lyricsplus.bridge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Live preview of the 3D lyric look: selected font, placement (arc / sky / land / ...),
 * animation and color. Tap to replay. It mirrors the math used by the add-on.
 */
class LyricPreview(ctx: Context, private val st: Settings) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sample = "Feel the music in the sky tonight"
    private val cycle = 4.8f
    private val lineDur = 3.4f
    private var t0 = SystemClock.uptimeMillis()

    private class G(val ch: String, val cx: Float, val cy: Float, val adv: Float, val sc: Float,
                    val word: Int, val ord: Int, val at: Float)

    fun restart() { t0 = SystemClock.uptimeMillis() }

    private val frame = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (isShown) invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(frame); post(frame) }
    override fun onDetachedFromWindow() { removeCallbacks(frame); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) restart()
        return true
    }

    private fun color(): Int {
        val c = if (st.w3dColor == 1) (Accent.of(MediaState.track?.cover) and 0xFFFFFF)
        else Settings.COLOR_HEX[st.w3dColor.coerceIn(0, Settings.COLOR_HEX.size - 1)]
        return c or (0xFF shl 24)
    }

    // ------------------------------------------------------------------ layout
    private fun layout(w: Float, h: Float, em: Float): List<G> {
        text.typeface = Fonts.get(context, st.w3dFont)
        text.textSize = em
        val raw = if (st.floatCaps) sample.uppercase() else sample
        val ws = raw.split(" ").filter { it.isNotEmpty() }
        val sf = st.w3dSpacing / 100f
        val track = 0.08f * em * sf
        val space = text.measureText(" ") + track + 0.3f * em * sf
        val widths = ws.map { text.measureText(it) + track * (it.length - 1) }
        val weights = ws.map { it.length + 1f }
        val total = weights.sum()
        val ats = ArrayList<Float>()
        var acc = 0f
        for (x in weights) { ats.add(acc / total * lineDur * 0.8f); acc += x }

        val out = ArrayList<G>()
        var ord = 0
        fun addWord(wi: Int, cx: Float, cy: Float, sc: Float, yOf: (Float) -> Float) {
            val word = ws[wi]
            var x = cx - widths[wi] * sc / 2f
            for (ch in word) {
                val s = ch.toString()
                val a = text.measureText(s) * sc
                val gx = x + a / 2f
                out.add(G(s, gx, yOf(gx) + cy, a, sc, wi, ord++, ats[wi]))
                x += a + track * sc
            }
        }

        val where = st.w3dWhere
        if (where == 3) {                                         // scatter
            val slots = listOf(0.22f to 0.24f, 0.60f to 0.16f, 0.82f to 0.34f, 0.18f to 0.46f,
                0.50f to 0.42f, 0.78f to 0.52f, 0.30f to 0.62f)
            val scs = listOf(1.2f, 0.95f, 1.35f, 0.9f, 1.15f, 1.0f, 1.25f)
            for (i in ws.indices) {
                val s = slots[i % slots.size]
                addWord(i, w * s.first, h * s.second, scs[i % scs.size]) { 0f }
            }
            return out
        }
        if (where == 5) {                                         // ring
            val n = ws.size
            for (i in 0 until n) {
                val a = (if (n == 1) 0.0 else -110.0 + 220.0 * i / (n - 1)) * PI / 180.0
                val sc = 0.65f + 0.4f * cos(a).toFloat()
                addWord(i, w * (0.5f + 0.42f * sin(a).toFloat()), h * 0.34f - 0.06f * h * cos(a).toFloat(), sc) { 0f }
            }
            return out
        }
        // rows
        val maxW = w * 0.9f
        val rows = ArrayList<MutableList<Int>>()
        rows.add(ArrayList())
        var rw = 0f
        for (i in ws.indices) {
            val cur = rows.last()
            val add = if (cur.isEmpty()) widths[i] else space + widths[i]
            if (cur.isNotEmpty() && rw + add > maxW) { rows.add(arrayListOf(i)); rw = widths[i] }
            else { cur.add(i); rw += add }
        }
        val rowGap = em * (1.1f + 0.35f * sf)
        val baseY = when (where) {
            1 -> h * 0.16f
            2 -> h * 0.84f - (rows.size - 1) * rowGap
            else -> h * 0.34f
        }
        for ((r, row) in rows.withIndex()) {
            val tw = row.sumOf { widths[it].toDouble() }.toFloat() + space * (row.size - 1)
            var x = w / 2f - tw / 2f + (if (where == 4) 0f else (if (r % 2 == 0) -0.03f else 0.03f) * w)
            val cy = baseY + r * rowGap
            for (wi in row) {
                val cx = x + widths[wi] / 2f
                addWord(wi, cx, cy, 1f) { gx ->
                    when (where) {
                        0, 1 -> { val nx = (gx - w / 2f) / (w / 2f); nx * nx * h * 0.10f }
                        4 -> sin((gx / (em * 2.2f)).toDouble()).toFloat() * em * 0.7f
                        else -> 0f
                    }
                }
                x += widths[wi] + space
            }
        }
        return out
    }

    // ------------------------------------------------------------------ animation (same as the add-on)
    private class AS(val a: Float, val s: Float, val dx: Float, val dy: Float, val rot: Float)

    private fun animState(anim: Int, t: Float, em: Float): AS {
        val spd = max(0.25f, st.animSpeed / 100f)
        var dur = 0.45f; var s0 = 1f; var oy = 0f; var ox = 0f; var rot0 = 0f; var wave = 0f
        when (anim) {
            1 -> { dur = 0.35f; s0 = 0f }
            2 -> { dur = 0.5f; oy = -em * 1.3f }
            3 -> { dur = 0.5f; oy = em * 1.3f }
            4 -> { dur = 0.5f; ox = -em * 3f }
            5 -> { dur = 0.55f; s0 = 0.2f; rot0 = 270f }
            6 -> { dur = 0.5f; s0 = 2.6f }
            7 -> { dur = 0.12f }
            8 -> { wave = em * 0.2f }
        }
        dur /= spd
        val p = min(1f, max(0f, t) / dur)
        val e = 1f - (1f - p).pow(3)
        val a = min(1f, max(0f, t) / (dur * 0.6f))
        val wy = wave * sin(Math.toRadians((t * 200f).toDouble())).toFloat()
        return AS(a, s0 + (1f - s0) * e, ox * (1f - e), oy * (1f - e) + wy, rot0 * (1f - e))
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (190 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val hor = h * 0.66f
        bg.shader = LinearGradient(0f, 0f, 0f, hor, 0xFF2B3A78.toInt(), 0xFFFFA45C.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, hor, bg)
        bg.shader = LinearGradient(0f, hor, 0f, h, 0xFF3F7A2E.toInt(), 0xFF22421A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, hor, w, h, bg)
        bg.shader = null
        bg.color = Color.argb(70, 255, 230, 160)
        c.drawCircle(w * 0.82f, hor - 6 * d, 20 * d, bg)

        val em = h * 0.15f * (st.w3dSize / 100f).coerceIn(0.5f, 1.6f) * (if (st.w3dWhere == 1) 1.1f else 1f)
        val glyphs = layout(w, h, em)
        val tt = ((SystemClock.uptimeMillis() - t0) / 1000f) % cycle
        val fade = if (tt > cycle - 0.5f) ((cycle - tt) / 0.5f).coerceIn(0f, 1f) else 1f
        val col = color()
        val spd = max(0.25f, st.animSpeed / 100f)
        text.typeface = Fonts.get(context, st.w3dFont)

        for (g in glyphs) {
            val anim = if (st.w3dAnim == 9) intArrayOf(1, 2, 3, 4, 5, 6)[(g.word * 5) % 6] else st.w3dAnim
            val start = if (anim == 7) g.at + g.ord * 0.05f / spd else g.at
            val local = tt - start
            if (local < 0f) continue
            val s = animState(anim, local, em)
            val alpha = s.a * fade
            if (alpha <= 0.01f) continue
            text.textSize = em * g.sc
            c.save()
            c.translate(g.cx + s.dx, g.cy + s.dy)
            c.rotate(s.rot)
            c.scale(s.s, s.s)
            val tx = -g.adv / g.sc / 2f * g.sc
            if (st.w3dShadow) {
                text.color = Color.argb((115 * alpha).toInt(), 0, 0, 0)
                c.drawText(g.ch, tx + em * 0.03f, em * 0.32f + em * 0.035f, text)
            }
            text.color = Color.argb((255 * alpha).toInt(), Color.red(col), Color.green(col), Color.blue(col))
            c.drawText(g.ch, tx, em * 0.32f, text)
            c.restore()
        }
    }
}
