package com.lyricsplus.bridge

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Full-screen, touch-through overlay:
 *  1) floating lyrics: words pop in one by one along curved arcs (like the reference video)
 *  2) top "karaoke pill": cover + current line with the active word highlighted + equalizer.
 *
 * NOTE: this is drawn on the screen (2D). It is not anchored to the 3D world of the game.
 * Word timing is estimated (LRCLIB only has line timestamps): words share the line duration by length.
 */
class FloatView(ctx: Context, private val st: Settings) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val appCtx = ctx.applicationContext
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val pillTxt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val clip = Path()
    private val rf = RectF()
    private val src = Rect()

    private class Row(val idx: List<Int>, val off: FloatArray, val width: Float)

    private var key = ""
    private var words: List<String> = emptyList()
    private var wordW = FloatArray(0)
    private var pillWW = FloatArray(0)
    private var starts = FloatArray(0)
    private var rows: List<Row> = emptyList()
    private var lineT0 = 0L
    private var lineDur = 3000L
    private var fsize = 40f

    private var floatA = 0f
    private var pillA = 0f
    private var pillScroll = 0f
    private var lastNs = 0L

    private fun approach(v: Float, t: Float, dd: Float): Float =
        if (v < t) min(v + dd, t) else max(v - dd, t)

    private val frame = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0.033f else min(0.1f, (now - lastNs) / 1e9f)
            lastNs = now
            val ok = MediaState.track != null && LyricsRepo.lines.isNotEmpty() && MediaState.playing
            floatA = approach(floatA, if (ok && st.floatLyrics) 1f else 0f, dt * 5f)
            pillA = approach(pillA, if (ok && st.topPill) 1f else 0f, dt * 4f)
            invalidate()
            if (ok || floatA > 0f || pillA > 0f) {
                postDelayed(this, st.frameMs())          // ~30 fps, light on the game
            } else {
                lastNs = 0L
                postDelayed(this, 300)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(frame)
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    private fun face(i: Int): Typeface = Fonts.get(appCtx, i)

    // ------------------------------------------------------------ layout of the current line
    private fun relayout(w: Float, h: Float) {
        val lines = LyricsRepo.lines
        val idx = LyricsRepo.indexAt(MediaState.position())
        val k2 = "${MediaState.trackId}:$idx:${w.toInt()}x${h.toInt()}:${st.floatCaps}:${st.floatSize}:${st.floatFont}"
        if (k2 == key) return
        key = k2

        if (idx < 0 || idx >= lines.size) {
            words = emptyList(); rows = emptyList(); return
        }
        val line = lines[idx]
        val raw = if (st.floatCaps) line.text.uppercase() else line.text
        words = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) { rows = emptyList(); return }

        lineT0 = line.t
        val next = lines.getOrNull(idx + 1)?.t ?: (line.t + 4000)
        lineDur = (next - line.t).coerceIn(1200L, 8000L)

        fsize = min(w, h) * 0.095f * st.floatSize / 100f
        txt.typeface = face(st.floatFont)
        txt.textSize = fsize
        wordW = FloatArray(words.size) { txt.measureText(words[it]) }
        val space = txt.measureText(" ")

        pillTxt.textSize = 13f * d
        pillWW = FloatArray(words.size) { pillTxt.measureText(words[it]) }

        val weights = FloatArray(words.size) { words[it].length + 1f }
        val total = weights.sum()
        starts = FloatArray(words.size)
        var acc = 0f
        for (i in words.indices) {
            starts[i] = acc / total * lineDur * 0.8f
            acc += weights[i]
        }

        val maxRow = w * 0.72f
        val list = ArrayList<Row>()
        var cur = ArrayList<Int>()
        var curW = 0f
        fun flush() {
            if (cur.isEmpty()) return
            val off = FloatArray(cur.size)
            var a = 0f
            for (j in cur.indices) { off[j] = a; a += wordW[cur[j]] + space }
            list.add(Row(cur, off, a - space))
            cur = ArrayList()
            curW = 0f
        }
        for (i in words.indices) {
            val add = if (cur.isEmpty()) wordW[i] else space + wordW[i]
            if (cur.isNotEmpty() && curW + add > maxRow) flush()
            curW += if (cur.isEmpty()) wordW[i] else space + wordW[i]
            cur.add(i)
        }
        flush()
        rows = list
        pillScroll = 0f
    }

    // ------------------------------------------------------------ draw
    override fun onDraw(c: Canvas) {
        if (floatA <= 0f && pillA <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        relayout(w, h)
        if (words.isEmpty()) return
        val lt = (MediaState.position() - lineT0).toFloat()
        if (floatA > 0f) drawFloating(c, w, h, lt)
        if (pillA > 0f) drawPill(c, w, lt)
    }

    private fun backOut(p: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val u = p - 1f
        return 1f + c3 * u * u * u + c1 * u * u
    }

    private fun drawFloating(c: Canvas, w: Float, h: Float, lt: Float) {
        if (rows.isEmpty()) return
        val radius = w * 1.1f
        val sinPhi = (0.475f * w / radius).coerceAtMost(0.99f)
        val phi = Math.toDegrees(asin(sinPhi.toDouble())).toFloat()
        val arcLen = (radius * 2.0 * Math.toRadians(phi.toDouble())).toFloat()
        val fade = if (lt > lineDur - 250f) ((lineDur - lt) / 250f).coerceIn(0f, 1f) else 1f
        val col = if (st.floatAccent) Accent.of(MediaState.track?.cover) else Color.WHITE
        val shR = when (st.floatShadow) { 0 -> 0f; 2 -> 12f * d; else -> 6f * d }

        for ((r, row) in rows.withIndex()) {
            val baseY = h * 0.2f + r * fsize * 1.4f
            path.reset()
            rf.set(w / 2f - radius, baseY, w / 2f + radius, baseY + 2f * radius)
            path.addArc(rf, 270f - phi, 2f * phi)
            val stagger = (if (r % 2 == 0) -0.05f else 0.05f) * w
            val start = (arcLen - row.width) / 2f + stagger

            for (j in row.idx.indices) {
                val wi = row.idx[j]
                val t = lt - starts[wi]
                if (t < 0f) continue
                val p = (t / 220f).coerceIn(0f, 1f)
                val sc = 0.6f + 0.4f * (if (p < 1f) backOut(p) else 1f)
                val a = p * fade * floatA
                if (a <= 0.01f) continue
                txt.textSize = fsize * sc
                txt.color = col
                txt.alpha = (255 * a).roundToInt().coerceIn(0, 255)
                if (shR > 0f) txt.setShadowLayer(shR, 0f, 3f * d, Color.argb((170 * a).roundToInt(), 0, 0, 0))
                else txt.clearShadowLayer()
                val hOff = start + row.off[j] + wordW[wi] * (1f - sc) / 2f
                c.drawTextOnPath(words[wi], path, hOff, (1f - p) * fsize * 0.35f, txt)
            }
        }
        txt.clearShadowLayer()
    }

    private fun drawPill(c: Canvas, w: Float, lt: Float) {
        val a = pillA
        val ph = 34f * d
        val top = 10f * d - (1f - a) * (ph + 10f * d)
        val spaceW = pillTxt.measureText(" ")
        var totalW = 0f
        for (i in pillWW.indices) totalW += pillWW[i] + (if (i > 0) spaceW else 0f)

        val maxTextW = min(w * 0.5f, 260f * d)
        val textW = min(totalW + 8f * d, maxTextW)

        var ai = -1
        for (i in words.indices) if (starts[i] <= lt) ai = i

        // scroll so the active word stays visible
        var ax = 0f
        for (i in 0 until max(ai, 0)) ax += pillWW[i] + spaceW
        val aw = if (ai >= 0) pillWW[ai] else 0f
        val target = if (totalW > textW) (ax + aw / 2f - textW / 2f).coerceIn(0f, totalW - textW + 8f * d) else 0f
        pillScroll += (target - pillScroll) * 0.25f

        val pw = 12f * d + 24f * d + 8f * d + textW + 8f * d + 20f * d + 12f * d
        val left = (w - pw) / 2f
        val acc = Accent.of(MediaState.track?.cover)
        val hsv = FloatArray(3)
        Color.colorToHSV(acc, hsv); hsv[2] *= 0.7f
        val chip = Color.HSVToColor(hsv)

        rf.set(left, top, left + pw, top + ph)
        fill.color = Color.argb((215 * a).roundToInt(), 14, 14, 20)
        c.drawRoundRect(rf, ph / 2f, ph / 2f, fill)
        strokeP.strokeWidth = d
        strokeP.color = Color.argb((50 * a).roundToInt(), 255, 255, 255)
        c.drawRoundRect(rf, ph / 2f, ph / 2f, strokeP)

        // cover (circle)
        val ccx = left + 12f * d + 12f * d
        val ccy = top + ph / 2f
        val cov: Bitmap? = MediaState.track?.cover
        c.save()
        clip.reset(); clip.addCircle(ccx, ccy, 12f * d, Path.Direction.CW)
        c.clipPath(clip)
        if (cov != null) {
            val side = min(cov.width, cov.height)
            src.set((cov.width - side) / 2, (cov.height - side) / 2, (cov.width + side) / 2, (cov.height + side) / 2)
            rf.set(ccx - 12f * d, ccy - 12f * d, ccx + 12f * d, ccy + 12f * d)
            bmpPaint.alpha = (255 * a).roundToInt()
            c.drawBitmap(cov, src, rf, bmpPaint)
        } else {
            fill.color = acc
            c.drawCircle(ccx, ccy, 12f * d, fill)
        }
        c.restore()

        // text with highlighted active word
        val x0 = left + 12f * d + 24f * d + 8f * d
        c.save()
        c.clipRect(x0, top, x0 + textW, top + ph)
        var x = x0 - pillScroll
        val baseline = top + ph / 2f + pillTxt.textSize * 0.35f
        for (i in words.indices) {
            if (i == ai) {
                rf.set(x - 4f * d, top + 6f * d, x + pillWW[i] + 4f * d, top + ph - 6f * d)
                fill.color = Color.argb((255 * a).roundToInt(), Color.red(chip), Color.green(chip), Color.blue(chip))
                c.drawRoundRect(rf, 8f * d, 8f * d, fill)
            }
            pillTxt.color = Color.WHITE
            pillTxt.alpha = ((if (i > ai) 150 else 255) * a).roundToInt()
            c.drawText(words[i], x, baseline, pillTxt)
            x += pillWW[i] + spaceW
        }
        c.restore()

        // equalizer bars
        val bx = x0 + textW + 8f * d
        val tms = SystemClock.uptimeMillis() / 1000f
        fill.color = Color.argb((255 * a).roundToInt(), Color.red(acc), Color.green(acc), Color.blue(acc))
        for (b in 0..2) {
            val hh = (0.35f + 0.65f * abs(sin(tms * (3f + b * 1.7f) + b))) * 14f * d
            val bl = bx + b * 7f * d
            rf.set(bl, ccy + 7f * d - hh, bl + 4f * d, ccy + 7f * d)
            c.drawRoundRect(rf, 2f * d, 2f * d, fill)
        }
    }
}
