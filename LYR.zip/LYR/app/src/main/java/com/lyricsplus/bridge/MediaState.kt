package com.lyricsplus.bridge

import android.graphics.Bitmap
import android.media.session.MediaController
import android.os.SystemClock

class Track(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val cover: Bitmap?,
    val pkg: String
)

/** Single shared snapshot of what is playing right now (from Spotify, YouTube Music, etc.). */
object MediaState {
    @Volatile var track: Track? = null
    @Volatile var playing: Boolean = false
    @Volatile var trackId: Int = 0
    @Volatile var controller: MediaController? = null

    @Volatile var basePos: Long = 0L
    @Volatile var baseTime: Long = 0L
    @Volatile var speed: Float = 1f

    fun position(): Long {
        val t = track ?: return 0L
        var p = basePos
        if (playing) p += ((SystemClock.elapsedRealtime() - baseTime) * speed).toLong()
        if (p < 0) p = 0
        return if (t.durationMs > 0 && p > t.durationMs) t.durationMs else p
    }

    fun toggle() {
        val c = controller ?: return
        if (playing) c.transportControls.pause() else c.transportControls.play()
    }

    fun play() {
        controller?.transportControls?.play()
    }

    fun pause() {
        controller?.transportControls?.pause()
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun prev() {
        controller?.transportControls?.skipToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.transportControls?.seekTo(ms)
        basePos = ms
        baseTime = SystemClock.elapsedRealtime()
    }
}
