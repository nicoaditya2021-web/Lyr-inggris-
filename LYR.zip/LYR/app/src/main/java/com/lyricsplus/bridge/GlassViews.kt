package com.lyricsplus.bridge

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.animation.AccelerateDecelerateInterpolator
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

object Ui {
    fun mix(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        fun c(p: Int, q: Int) = (p + (q - p) * x).roundToInt()
        return Color.argb(
            c(Color.alpha(a), Color.alpha(b)), c(Color.red(a), Color.red(b)),
            c(Color.green(a), Color.green(b)), c(Color.blue(a), Color.blue(b))
        )
    }

    /** springy press feedback; does not consume the touch so clicks still work */
    fun press(v: View) {
        v.setOnTouchListener { view, e ->
            val action = e.actionMasked
            if (action == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(280)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
            }
            false
        }
    }

    fun fmt(ms: Long): String {
        val s = max(0L, ms) / 1000
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }
}

/** Dark background with three soft color blobs. They are GPU layers moved with property animators,
 *  so nothing is redrawn per frame (cheap, smooth, cool). Paused when the window is hidden. */
class GlassBg(ctx: Context) : FrameLayout(ctx) {
    private val drawables = ArrayList<GradientDrawable>()
    private val anims = ArrayList<ObjectAnimator>()
    private val alphas = intArrayOf(110, 85, 75)
    private val colors = intArrayOf(Accent.DEFAULT, 0xFF7C3AED.toInt(), 0xFF2563EB.toInt())
    private var accent = Accent.DEFAULT
    private var colorAnim: ValueAnimator? = null

    init {
        setBackgroundColor(0xFF09090E.toInt())
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val size = (w * 1.35f).toInt()
        val starts = arrayOf(floatArrayOf(-0.25f * w, -0.25f * w), floatArrayOf(0.45f * w, 0.30f * h), floatArrayOf(-0.30f * w, 0.62f * h))
        val ends = arrayOf(floatArrayOf(0.15f * w, 0.10f * w), floatArrayOf(0.05f * w, 0.52f * h), floatArrayOf(0.20f * w, 0.80f * h))
        val durs = longArrayOf(19000L, 23000L, 27000L)
        for (i in 0 until 3) {
            val g = GradientDrawable()
            g.gradientType = GradientDrawable.RADIAL_GRADIENT
            g.gradientRadius = size / 2f
            g.colors = intArrayOf(Color.argb(alphas[i], Color.red(colors[i]), Color.green(colors[i]), Color.blue(colors[i])), Color.TRANSPARENT)
            drawables.add(g)
            val v = View(ctx)
            v.background = g
            v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            v.translationX = starts[i][0]
            v.translationY = starts[i][1]
            addView(v, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START))
            val ax = ObjectAnimator.ofFloat(v, View.TRANSLATION_X, starts[i][0], ends[i][0])
            val ay = ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, starts[i][1], ends[i][1])
            for (a2 in listOf(ax, ay)) {
                a2.duration = durs[i]
                a2.repeatCount = ValueAnimator.INFINITE
                a2.repeatMode = ValueAnimator.REVERSE
                a2.interpolator = AccelerateDecelerateInterpolator()
                anims.add(a2)
            }
        }
    }

    private fun startAnims() {
        if (Settings(context).perf >= 2) return
        for (a in anims) {
            if (a.isPaused) a.resume() else if (!a.isStarted) a.start()
        }
    }

    private fun stopAnims() {
        for (a in anims) if (a.isStarted && !a.isPaused) a.pause()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); startAnims() }
    override fun onDetachedFromWindow() { stopAnims(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE) startAnims() else stopAnims()
    }

    /** tint the first blob with the album color (smooth cross-fade) */
    fun setAccent(c: Int) {
        if (c == accent) return
        val from = accent
        accent = c
        colorAnim?.cancel()
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 700
        va.addUpdateListener {
            val m = Ui.mix(from, c, it.animatedValue as Float)
            drawables[0].colors = intArrayOf(Color.argb(alphas[0], Color.red(m), Color.green(m), Color.blue(m)), Color.TRANSPARENT)
        }
        colorAnim = va
        va.start()
    }
}

/** Frosted-glass container: translucent gradient fill + light-catching gradient border. */
open class GlassLayout(
    ctx: Context,
    private val radiusDp: Float = 22f,
    private val tint: Int = 26
) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d * 1.2f
    }
    private val rf = RectF()

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fill.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(tint + 18, 255, 255, 255), Color.argb(max(tint - 8, 4), 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        stroke.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(Color.argb(130, 255, 255, 255), Color.argb(14, 255, 255, 255), Color.argb(90, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        rf.set(d * 0.6f, d * 0.6f, width - d * 0.6f, height - d * 0.6f)
        val r = radiusDp * d
        c.drawRoundRect(rf, r, r, fill)
        c.drawRoundRect(rf, r, r, stroke)
    }
}

/** Switch with an overshooting glass knob. */
class GlassToggle(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pos = 0f
    private var anim: ValueAnimator? = null
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    init {
        setOnClickListener { setState(!checked, true); onChange?.invoke(checked) }
        Ui.press(this)
    }

    fun setState(v: Boolean, animate: Boolean) {
        checked = v
        anim?.cancel()
        val to = if (v) 1f else 0f
        if (!animate) { pos = to; invalidate(); return }
        val a = ValueAnimator.ofFloat(pos, to)
        a.duration = 280
        a.interpolator = OvershootInterpolator(1.4f)
        a.addUpdateListener { pos = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((52 * d).toInt(), (30 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val q = pos.coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.color = Ui.mix(Color.argb(64, 255, 255, 255), Accent.of(MediaState.track?.cover), q)
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        val kr = h / 2 - 3 * d
        val cx = h / 2 + (w - h) * pos
        p.color = Color.argb(60, 0, 0, 0)
        c.drawCircle(cx, h / 2 + d, kr, p)
        p.color = Color.WHITE
        c.drawCircle(cx, h / 2, kr, p)
    }
}

/** Prev / Next / Play-Pause with morph animation. */
class IconButton(ctx: Context, private val kind: Int) : View(ctx) {
    companion object { const val PREV = 0; const val NEXT = 1; const val PLAY = 2 }

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    private var morph = 0f           // 0 = pause icon, 1 = play icon
    private var morphTarget = 0f
    private var anim: ValueAnimator? = null
    private var sizeDp = 44

    init { Ui.press(this) }

    fun setSizeDp(s: Int) { sizeDp = s; requestLayout() }

    fun setPlaying(playing: Boolean) {
        val t = if (playing) 0f else 1f
        if (t == morphTarget) return
        morphTarget = t
        anim?.cancel()
        val a = ValueAnimator.ofFloat(morph, t)
        a.duration = 240
        a.addUpdateListener { morph = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((sizeDp * d).toInt(), (sizeDp * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        p.style = Paint.Style.FILL
        if (kind == PLAY) {
            p.color = Color.WHITE
            c.drawCircle(cx, cy, w / 2f * 0.94f, p)
            val s = w * 0.34f
            val dark = Color.rgb(16, 16, 20)
            val pa = 1f - morph
            if (pa > 0.01f) {
                c.save()
                val sc = 0.6f + 0.4f * pa
                c.scale(sc, sc, cx, cy)
                p.color = dark; p.alpha = (255 * pa).roundToInt()
                rf.set(cx - s * 0.38f, cy - s * 0.5f, cx - s * 0.08f, cy + s * 0.5f)
                c.drawRoundRect(rf, d * 1.5f, d * 1.5f, p)
                rf.set(cx + s * 0.08f, cy - s * 0.5f, cx + s * 0.38f, cy + s * 0.5f)
                c.drawRoundRect(rf, d * 1.5f, d * 1.5f, p)
                c.restore()
            }
            if (morph > 0.01f) {
                c.save()
                val sc = 0.6f + 0.4f * morph
                c.scale(sc, sc, cx, cy)
                p.color = dark; p.alpha = (255 * morph).roundToInt()
                path.reset()
                path.moveTo(cx - s * 0.32f, cy - s * 0.55f)
                path.lineTo(cx + s * 0.58f, cy)
                path.lineTo(cx - s * 0.32f, cy + s * 0.55f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            p.alpha = 255
        } else {
            val s = w * 0.36f
            val mirror = kind == PREV
            fun mx(x: Float) = if (mirror) 2f * cx - x else x
            p.color = Color.WHITE
            path.reset()
            path.moveTo(mx(cx - s * 0.45f), cy - s * 0.5f)
            path.lineTo(mx(cx + s * 0.35f), cy)
            path.lineTo(mx(cx - s * 0.45f), cy + s * 0.5f)
            path.close()
            c.drawPath(path, p)
            val bx = mx(cx + s * 0.5f)
            rf.set(bx - d * 1.8f, cy - s * 0.5f, bx + d * 1.8f, cy + s * 0.5f)
            c.drawRoundRect(rf, d * 1.5f, d * 1.5f, p)
        }
    }
}

/** Seekable progress bar with live time labels. */
class GlassProgress(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        textSize = 11 * d
    }
    private val rf = RectF()
    private var drag = false
    private var dragFrac = 0f
    private var accent = Accent.DEFAULT

    private val frame = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (isShown) {
                accent = Ui.mix(accent, Accent.of(MediaState.track?.cover), 0.1f)
                invalidate()
            }
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(frame); post(frame) }
    override fun onDetachedFromWindow() { removeCallbacks(frame); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (40 * d).toInt())
    }

    private fun fracAt(x: Float) = ((x - 4 * d) / (width - 8 * d)).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        val dur = MediaState.track?.durationMs ?: 0L
        val pos = if (drag) (dragFrac * dur).toLong() else MediaState.position()
        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        val l = 4 * d
        val r = width - 4 * d
        val cy = 10 * d
        val th = (if (drag) 6 else 4) * d
        rf.set(l, cy - th / 2, r, cy + th / 2)
        p.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(rf, th, th, p)
        rf.set(l, cy - th / 2, l + (r - l) * frac, cy + th / 2)
        p.color = accent
        c.drawRoundRect(rf, th, th, p)
        p.color = Color.WHITE
        c.drawCircle(l + (r - l) * frac, cy, (if (drag) 8 else 6) * d, p)
        tp.color = Color.argb(160, 255, 255, 255)
        tp.textAlign = Paint.Align.LEFT
        c.drawText(Ui.fmt(pos), l, cy + 24 * d, tp)
        tp.textAlign = Paint.Align.RIGHT
        c.drawText(Ui.fmt(dur), r, cy + 24 * d, tp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dur = MediaState.track?.durationMs ?: 0L
        if (dur <= 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                drag = true; dragFrac = fracAt(e.x)
            }
            MotionEvent.ACTION_MOVE -> dragFrac = fracAt(e.x)
            MotionEvent.ACTION_UP -> {
                MediaState.seekTo((dragFrac * dur).toLong()); drag = false
            }
            MotionEvent.ACTION_CANCEL -> drag = false
        }
        invalidate()
        return true
    }
}

/** Floating glass tab bar with a springy "liquid lens" that follows your finger. */
class NavBar(
    ctx: Context,
    private val labels: List<String>,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val n = labels.size
    private var selected = 0
    private var pos = 0f
    private var vel = 0f
    private var target = 0f
    private var pressedLens = false
    private var lensScale = 1f
    private val sel = FloatArray(n)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private val lensP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lensS = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textSize = 10.5f * d
        textAlign = Paint.Align.CENTER
    }
    private val rf = RectF()
    private val path = Path()
    private var running = false
    private var lastNs = 0L

    private val frame = Runnable { stepAndDraw() }

    private fun tabW() = width.toFloat() / n
    private fun center(i: Int) = (i + 0.5f) * tabW()
    private fun idxAt(x: Float) = (x / tabW()).toInt().coerceIn(0, n - 1)
    private fun clampX(x: Float) = x.coerceIn(tabW() * 0.5f, width - tabW() * 0.5f)

    fun selectTab(i: Int) {
        selected = i
        if (!pressedLens) target = center(i)
        kick()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pos = center(selected); target = pos; vel = 0f
        for (i in 0 until n) sel[i] = if (i == selected) 1f else 0f
        fill.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(40, 255, 255, 255), Color.argb(14, 255, 255, 255), Shader.TileMode.CLAMP
        )
        stroke.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(Color.argb(140, 255, 255, 255), Color.argb(16, 255, 255, 255), Color.argb(100, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        lensS.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(170, 255, 255, 255), Color.argb(40, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    private fun kick() {
        if (!running) { running = true; lastNs = 0L; postOnAnimation(frame) }
    }

    private fun stepAndDraw() {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.032f, (now - lastNs) / 1e9f)
        lastNs = now
        val acc = -520f * (pos - target) - 30f * vel
        vel += acc * dt
        pos += vel * dt
        var moving = true
        if (abs(pos - target) < 0.5f && abs(vel) < 5f) { pos = target; vel = 0f; moving = false }

        val ls = if (pressedLens) 1.1f else 1f
        lensScale += (ls - lensScale) * min(1f, dt * 14f)
        if (abs(ls - lensScale) > 0.003f) moving = true

        val hi = if (pressedLens) idxAt(target) else selected
        for (i in 0 until n) {
            val t = if (i == hi) 1f else 0f
            sel[i] += (t - sel[i]) * min(1f, dt * 12f)
            if (abs(t - sel[i]) > 0.01f) moving = true
        }
        invalidate()
        if (moving) postOnAnimation(frame) else running = false
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rf.set(d, d, w - d, h - d)
        c.drawRoundRect(rf, h / 2, h / 2, fill)
        c.drawRoundRect(rf, h / 2, h / 2, stroke)

        // liquid lens: stretches while moving, grows while pressed
        val stretch = 1f + min(0.45f, abs(vel) / 2200f)
        val lw = tabW() * 0.86f * stretch * lensScale
        val lh = (h - 12 * d) * lensScale
        rf.set(pos - lw / 2, h / 2 - lh / 2, pos + lw / 2, h / 2 + lh / 2)
        lensP.color = Color.argb(if (pressedLens) 58 else 40, 255, 255, 255)
        c.drawRoundRect(rf, lh / 2, lh / 2, lensP)
        c.drawRoundRect(rf, lh / 2, lh / 2, lensS)

        for (i in 0 until n) {
            val cx = center(i)
            val a = (150 + 105 * sel[i]).roundToInt()
            val cy = h * 0.38f - 3 * d * sel[i]
            icon.color = Color.argb(a, 255, 255, 255)
            drawIcon(c, i, cx, cy, 22 * d)
            text.color = Color.argb(a, 255, 255, 255)
            c.drawText(labels[i], cx, h * 0.80f, text)
        }
    }

    private fun drawIcon(c: Canvas, i: Int, cx: Float, cy: Float, s: Float) {
        path.reset()
        when (i) {
            0 -> { // home
                path.moveTo(cx - s * 0.5f, cy - s * 0.02f)
                path.lineTo(cx, cy - s * 0.5f)
                path.lineTo(cx + s * 0.5f, cy - s * 0.02f)
                path.moveTo(cx - s * 0.36f, cy - s * 0.1f)
                path.lineTo(cx - s * 0.36f, cy + s * 0.45f)
                path.lineTo(cx + s * 0.36f, cy + s * 0.45f)
                path.lineTo(cx + s * 0.36f, cy - s * 0.1f)
            }
            1 -> { // lyrics bubble
                rf.set(cx - s * 0.5f, cy - s * 0.42f, cx + s * 0.5f, cy + s * 0.22f)
                path.addRoundRect(rf, s * 0.16f, s * 0.16f, Path.Direction.CW)
                path.moveTo(cx - s * 0.18f, cy + s * 0.22f)
                path.lineTo(cx - s * 0.28f, cy + s * 0.5f)
                path.lineTo(cx + s * 0.04f, cy + s * 0.22f)
                path.moveTo(cx - s * 0.26f, cy - s * 0.17f)
                path.lineTo(cx + s * 0.26f, cy - s * 0.17f)
                path.moveTo(cx - s * 0.26f, cy + s * 0.03f)
                path.lineTo(cx + s * 0.08f, cy + s * 0.03f)
            }
            2 -> { // cube
                path.moveTo(cx, cy - s * 0.5f)
                path.lineTo(cx + s * 0.43f, cy - s * 0.25f)
                path.lineTo(cx + s * 0.43f, cy + s * 0.25f)
                path.lineTo(cx, cy + s * 0.5f)
                path.lineTo(cx - s * 0.43f, cy + s * 0.25f)
                path.lineTo(cx - s * 0.43f, cy - s * 0.25f)
                path.close()
                path.moveTo(cx - s * 0.43f, cy - s * 0.25f)
                path.lineTo(cx, cy)
                path.lineTo(cx + s * 0.43f, cy - s * 0.25f)
                path.moveTo(cx, cy)
                path.lineTo(cx, cy + s * 0.5f)
            }
            else -> { // sliders
                for (k in -1..1) {
                    val y = cy + k * s * 0.32f
                    path.moveTo(cx - s * 0.5f, y)
                    path.lineTo(cx + s * 0.5f, y)
                }
                path.addCircle(cx - s * 0.2f, cy - s * 0.32f, s * 0.12f, Path.Direction.CW)
                path.addCircle(cx + s * 0.25f, cy, s * 0.12f, Path.Direction.CW)
                path.addCircle(cx - s * 0.05f, cy + s * 0.32f, s * 0.12f, Path.Direction.CW)
            }
        }
        c.drawPath(path, icon)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                pressedLens = true; target = clampX(e.x); kick()
            }
            MotionEvent.ACTION_MOVE -> { target = clampX(e.x); kick() }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.x)
                pressedLens = false
                val changed = i != selected
                selected = i
                target = center(i)
                kick()
                if (changed) onSelect(i)
            }
            MotionEvent.ACTION_CANCEL -> { pressedLens = false; target = center(selected); kick() }
        }
        return true
    }
}
