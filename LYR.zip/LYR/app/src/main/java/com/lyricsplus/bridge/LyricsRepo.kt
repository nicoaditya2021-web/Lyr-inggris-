package com.lyricsplus.bridge

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/** Synced lyrics from LRCLIB (https://lrclib.net). Needs internet. */
object LyricsRepo {
    class Line(val t: Long, val text: String)

    @Volatile var lines: List<Line> = emptyList()
    @Volatile var status: String = "No track"
    @Volatile var offsetMs: Long = 0L
    private var appCtx: android.content.Context? = null

    fun init(ctx: android.content.Context) { appCtx = ctx.applicationContext }

    fun lrcFile(ctx: android.content.Context, artist: String, title: String, durMs: Long): java.io.File {
        val dir = java.io.File(ctx.filesDir, "lrc")
        dir.mkdirs()
        val key = "$artist|$title|${durMs / 1000}".hashCode()
        return java.io.File(dir, Integer.toHexString(key) + ".lrc")
    }

    /** forget the loaded lyrics so the next tick reloads them (after importing a .lrc) */
    fun invalidate() {
        loadedFor = -1
        synchronized(cache) { cache.clear() }
    }
    @Volatile private var loadedFor = -1
    private val cache = HashMap<String, List<Line>>()

    fun ensure(t: Track, id: Int) {
        if (loadedFor == id) return
        loadedFor = id
        lines = emptyList()
        status = "Loading lyrics…"
        val key = "${t.artist}|${t.title}|${t.durationMs / 1000}"
        val hit = synchronized(cache) { cache[key] }
        if (hit != null) {
            lines = hit
            status = if (hit.isEmpty()) "No synced lyrics" else ""
            return
        }
        Thread {
            var res: List<Line> = emptyList()
            val c = appCtx
            if (c != null) {
                try {
                    val f = lrcFile(c, t.artist, t.title, t.durationMs)
                    if (f.exists()) res = parseLrc(f.readText())
                } catch (_: Exception) {}
            }
            if (res.isEmpty()) res = fetch(t)
            if (loadedFor != id) return@Thread
            synchronized(cache) { if (cache.size > 40) cache.clear(); cache[key] = res }
            lines = res
            status = if (res.isEmpty()) "No synced lyrics" else ""
        }.start()
    }

    /** index of the active line at [posMs], -1 before the first line */
    fun indexAt(posMs: Long): Int {
        val l = lines
        if (l.isEmpty()) return -1
        val p = posMs + 150 + offsetMs
        var lo = 0
        var hi = l.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (l[mid].t <= p) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    private fun jstr(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun http(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "LYR/1.0.0")
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

    private fun fetch(t: Track): List<Line> {
        val dur = t.durationMs / 1000
        val base = "https://lrclib.net/api"
        // 1) exact match
        if (dur > 0) {
            val body = http("$base/get?artist_name=${enc(t.artist)}&track_name=${enc(t.title)}" +
                    "&album_name=${enc(t.album)}&duration=$dur")
            val synced = body?.let { try { jstr(JSONObject(it), "syncedLyrics") } catch (_: Exception) { "" } }
            if (!synced.isNullOrBlank()) return parseLrc(synced)
        }
        // 2) search, closest duration wins
        val clean = t.title.replace(Regex("\\s*[(\\[].*?[)\\]]"), "").replace(Regex("\\s+-\\s+.*$"), "").trim()
        val body = http("$base/search?track_name=${enc(clean.ifBlank { t.title })}&artist_name=${enc(t.artist)}")
            ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            var best: String? = null
            var bestDiff = Long.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = jstr(o, "syncedLyrics")
                if (s.isBlank()) continue
                val d = abs(o.optLong("duration", 0L) - dur)
                if (d < bestDiff) { bestDiff = d; best = s }
            }
            if (best != null) parseLrc(best) else emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private val tsRe = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parseLrc(text: String): List<Line> {
        val out = ArrayList<Line>()
        for (raw in text.lines()) {
            val ms = tsRe.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val content = raw.substring(ms.last().range.last + 1).trim()
            for (m in ms) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fr = m.groupValues[3]
                val frac = when (fr.length) { 0 -> 0L; 1 -> fr.toLong() * 100; 2 -> fr.toLong() * 10; else -> fr.take(3).toLong() }
                out.add(Line(min * 60000 + sec * 1000 + frac, content))
            }
        }
        out.sortBy { it.t }
        return out
    }
}
