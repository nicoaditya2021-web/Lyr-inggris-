package com.lyricsplus.bridge

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

/**
 * Reads the active MediaSession (Spotify, YouTube Music, YouTube, any player with MediaSession).
 * Android only allows this for an app that has "Notification access".
 */
class MediaListenerService : NotificationListenerService() {

    companion object {
        @Volatile var instance: MediaListenerService? = null
    }

    /** called when the built-in player stops, so the active external session is picked up again */
    fun resync() { refreshSessions() }

    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null
    private val comp by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { readMetadata(current) }
        override fun onPlaybackStateChanged(state: PlaybackState?) { readState(state) }
        override fun onSessionDestroyed() { refreshSessions() }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, comp)
            pick(m.getActiveSessions(comp))
        } catch (_: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        instance = null
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        current?.unregisterCallback(cb)
        current = null
        MediaState.controller = null
        MediaState.track = null
        MediaState.playing = false
        MediaState.trackId++
        super.onListenerDisconnected()
    }

    private fun refreshSessions() {
        try { pick(msm?.getActiveSessions(comp)) } catch (_: SecurityException) {}
    }

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()

        if (best != null && current != null && best.sessionToken == current!!.sessionToken) {
            readMetadata(best); readState(best.playbackState)
            return
        }
        current?.unregisterCallback(cb)
        current = best
        MediaState.controller = best
        if (best == null) {
            MediaState.track = null
            MediaState.playing = false
            MediaState.trackId++
            return
        }
        best.registerCallback(cb)
        readMetadata(best)
        readState(best.playbackState)
    }

    private fun readMetadata(c: MediaController?) {
        val md = c?.metadata ?: return
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        if (title.isBlank() && artist.isBlank()) return
        val old = MediaState.track
        val changed = old == null || old.title != title || old.artist != artist
        MediaState.track = Track(title, artist, album, if (dur > 0) dur else (old?.durationMs ?: 0L), bmp ?: (if (changed) null else old?.cover), c.packageName)
        if (changed) MediaState.trackId++
    }

    private fun readState(s: PlaybackState?) {
        if (s == null) { MediaState.playing = false; return }
        val playing = s.state == PlaybackState.STATE_PLAYING || s.state == PlaybackState.STATE_BUFFERING
        MediaState.playing = playing
        MediaState.basePos = s.position
        MediaState.baseTime = if (s.lastPositionUpdateTime > 0) s.lastPositionUpdateTime
        else android.os.SystemClock.elapsedRealtime()
        MediaState.speed = if (s.playbackSpeed == 0f) 1f else s.playbackSpeed

        // If this session paused and another one is playing, follow the playing one.
        if (!playing) {
            try {
                val others = msm?.getActiveSessions(comp)
                val p = others?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                if (p != null && p.sessionToken != current?.sessionToken) pick(others)
            } catch (_: SecurityException) {}
        }
    }
}
