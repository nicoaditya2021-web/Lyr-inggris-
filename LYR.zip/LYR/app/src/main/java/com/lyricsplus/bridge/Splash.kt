package com.lyricsplus.bridge

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object Credits {
    class P(val name: String, val role: String, val res: Int)
    val ALL: List<P> = listOf(
        P("Aerion", "Main Developer / Creator", R.drawable.avatar_aerion),
        P("Maxwle", "Contributor", R.drawable.avatar_maxwle),
        P("GIL", "Contributor", R.drawable.avatar_gil)
    )
}

/** Splash: logo, title and credits appear one after another, then it fades out. Tap to skip. */
class SplashView(ctx: Context, private val onDone: () -> Unit) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private var finished = false
    private var ringAnim: ObjectAnimator? = null
    private val kit = Kit(ctx, Settings(ctx)) {}

    init {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (T.dark) intArrayOf(0xFF0B2A5B.toInt(), 0xFF070B14.toInt()) else intArrayOf(0xFFD6E8FF.toInt(), 0xFFFFFFFF.toInt())
        )
        isClickable = true
        setOnClickListener { finish() }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL

        // logo with pulsing ring
        val logoBox = FrameLayout(ctx)
        val ring = View(ctx)
        val rg = GradientDrawable()
        rg.shape = GradientDrawable.OVAL
        rg.setStroke(dp(2), T.accent)
        ring.background = rg
        ring.alpha = 0f
        logoBox.addView(ring, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
        val logo = ImageView(ctx)
        logo.setImageDrawable(ctx.getDrawable(R.drawable.ic_launcher))
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        logo.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 26f * d) }
        }
        logo.clipToOutline = true
        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logoBox.addView(logo, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
        col.addView(logoBox, LinearLayout.LayoutParams(dp(150), dp(150)))

        val title = kit.tv("LYR", 34f, T.text, false)
        title.setTypeface(Fonts.get(ctx, 0), Typeface.BOLD)
        title.alpha = 0f
        title.translationY = dp(16).toFloat()
        col.addView(title, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })

        val sub = kit.tv("Lirik Minecraft, sinkron dengan musikmu", 14f, T.sub)
        sub.gravity = Gravity.CENTER
        sub.alpha = 0f
        sub.translationY = dp(12).toFloat()
        col.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })

        val head = kit.tv("Dibuat oleh", 12f, T.sub)
        head.alpha = 0f
        col.addView(head, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(40); bottomMargin = dp(12) })

        val rows = ArrayList<View>()
        for (p in Credits.ALL) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.addView(kit.avatar(p.res, 44, if (T.dark) 0xFF111A2C.toInt() else Color.WHITE))
            val tx = LinearLayout(ctx)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(kit.tv(p.name, 16f, T.text, true))
            tx.addView(kit.tv(p.role, 12.5f, T.sub))
            r.addView(tx, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
            r.alpha = 0f
            r.translationY = dp(18).toFloat()
            rows.add(r)
            col.addView(r, LinearLayout.LayoutParams(dp(230), -2).apply { bottomMargin = dp(10) })
        }
        addView(col, LayoutParams(-2, -2, Gravity.CENTER))

        val hint = kit.tv("Ketuk untuk lewati", 11.5f, T.sub)
        hint.alpha = 0f
        addView(hint, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(36) })

        // staged animations
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(650)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        ringAnim = ObjectAnimator.ofPropertyValuesHolder(
            ring,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.45f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.45f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.6f, 0f)
        ).apply {
            duration = 1400
            startDelay = 500
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
            start()
        }
        title.animate().alpha(1f).translationY(0f).setStartDelay(700).setDuration(450).setInterpolator(DecelerateInterpolator()).start()
        sub.animate().alpha(1f).translationY(0f).setStartDelay(950).setDuration(450).setInterpolator(DecelerateInterpolator()).start()
        head.animate().alpha(1f).setStartDelay(1350).setDuration(350).start()
        for ((i, r) in rows.withIndex()) {
            r.animate().alpha(1f).translationY(0f).setStartDelay(1550L + i * 380L).setDuration(420)
                .setInterpolator(AccelerateDecelerateInterpolator()).start()
        }
        hint.animate().alpha(0.8f).setStartDelay(2000).setDuration(400).start()
        postDelayed({ finish() }, 3600)
    }

    fun finish() {
        if (finished) return
        finished = true
        ringAnim?.cancel()
        animate().alpha(0f).setDuration(420).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onDone()
        }.start()
    }
}
