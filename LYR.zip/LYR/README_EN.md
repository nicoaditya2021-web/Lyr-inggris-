# LYR 1.0.0 (English)

LYR shows the lyrics of the song you are playing (Spotify, YouTube Music, ...) inside Minecraft Bedrock, in 3D.

- **App language**: Settings > App appearance > Language / Bahasa (System, Indonesia, English). "System" follows the phone's language.
- **Three lyric styles** (3D tab > Display style): Sky (in the skybox), World (words appear one by one in front of the camera and stay put), Chat (floating above your head like a Roblox chat).
- **Illustrated setup guide** inside the app: Home > Setup guide (8 steps, each marked Done automatically). The screenshots in the guide show the phone in Indonesian.
- **Install the add-on from the app**: the Home card "Install the LYR add-on" opens LYR.mcaddon in Minecraft (or share the file to a launcher).
- Build: see PUBLISH.md. Offline add-on tests: `node addon/test/sim.mjs`.

Connect once per session: `/wsserver ws://127.0.0.1:8765` (Minecraft Settings > General > Enable WebSockets must be on).
